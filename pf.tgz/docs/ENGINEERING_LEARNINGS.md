# Engineering Learnings

> Living document. Captures principles adopted from industry articles, our own failures, and patterns we discover.
> Each entry: what we learned, where it came from, how we adopted it, and what it changed.
>
> **Rule:** Before adding a new entry, answer: "Does this change how we build?" If no, skip it.

---

## How to Use This File

**For Raman:** When you read an article that passes the "changes how we build" test, add a brief entry below with the source link and one sentence on why it matters. We'll discuss and formalize in the next session.

**For Claude (AI sessions):** Read this file at session start alongside ROADMAP.md and GENAI_MANIFESTO.md. These learnings inform how code is written, not just what code is written.

---

## Adopted Principles

### L1: State Assumptions Before Acting

**Source:** Andrej Karpathy's CLAUDE.md observations (Jan 2026), via Forrest Chang's `andrej-karpathy-skills` repo.

**Problem it fixes:** LLMs silently pick an interpretation and run with it. In our case: test mock mismatches (e.g., `checkBlocklist` vs `scanBlocklist`), wrong class names (`MemoryCacheProvider` vs `InMemoryCacheProvider`), missing constructor params (`HealthRegistry` needs a version string).

**How we adopted it:** Before writing code that touches existing modules, read the actual exports and type signatures first. State what we're assuming. If there are multiple possible interpretations, surface them before proceeding.

**What it changed:** Sprint 6 integration tests required three rounds of fixes because assumptions about module APIs were wrong. This rule prevents that.

---

### L2: Minimal Change Surface

**Source:** Karpathy's CLAUDE.md, reinforced by our own `middleware.ts` sync collision and multiple sed commands touching wrong files.

**Problem it fixes:** Changing code you weren't asked to change. Side effects in patches. Rename operations that miss import references.

**How we adopted it:** "Read file before str_replace" (existing rule) + "state what you'll change and why before editing." Every changed line must trace to the request.

**What it changed:** Reduced fix-after-fix cycles. When the change surface is explicit, both human and AI can verify scope before applying.

---

### L3: Quality Gate as Success Criteria

**Source:** Karpathy's "Goal-Driven Execution" principle: define success criteria, loop until verified.

**Problem it fixes:** Vague "make it work" goals that require constant clarification. Code that passes one check but fails another.

**How we adopted it:** Our 22-point sustainability gate + `typecheck && lint && test` pipeline is exactly this. The gate IS the success criteria. No sprint ships without it. Added Phase 2: 8-point Accessibility Gate (A1-A8), coverage-must-not-decrease rule, incremental k6 load testing.

**What it changed:** Zero regressions shipped to main across 7 sprints. The gate catches everything before merge.

---

### L4: Provider Abstraction Over Direct Integration

**Source:** Our own architectural evolution (Phase 1-2). Reinforced by "The Agent-Native Rewrite" (Rodriguez, The Sequence Opinion #840, March 2026).

**Problem it fixes:** Vendor lock-in. Untestable code. Configuration scattered across files.

**How we adopted it:** Every external dependency gets an interface: AuthProvider, CacheProvider, AIProvider, ErrorReporter, RealtimeProvider, TranslationProvider (Phase 3), TTSProvider (Phase 3), STTProvider (Phase 3). Swap via env var. Mock for tests.

**What it changed:** 100% of tests run without external services. Provider swap = config change, not rewrite.

---

### L5: Agentic-Native From Day One

**Source:** Rodriguez, J. (2026). "The Agent-Native Rewrite." The Sequence Opinion #840.

**Problem it fixes:** Retrofitting agent support into systems designed for humans only. Schema migrations, identity model rewrites, authorization rethinking — all expensive.

**How we adopted it:** GenAI Manifesto P15-P18. Every RealtimeMessage carries agent identity, intent, trajectory, and memory hints. These fields activate when agents arrive — no migration needed.

**What it changed:** Phase 5 agent integration will be a configuration exercise, not an architecture rewrite.

---

### L6: Accessibility Is Not Optional

**Source:** Our own Phase 2 close audit. WCAG AA compliance gaps found in 9 components.

**Problem it fixes:** Shipping UI that screen readers can't navigate, forms that assistive tech can't operate, contrast ratios that fail for low-vision users.

**How we adopted it:** 8-point Accessibility Gate (A1-A8) required every sprint. E14/E15 in phase exit gate. `aria-live`, `aria-busy`, `role` attributes are not nice-to-haves — they're gating.

**What it changed:** 17 fixes across 9 components in Sprint 6. Accessibility is now as non-negotiable as test coverage.

---

### L7: Long Sessions Drift — Front-Load Critical Rules

**Source:** Rezvani, A. (2026). "Andrej Karpathy's CLAUDE.md: What Each Principle Really Fixes." Medium.

**Problem it fixes:** In long AI-assisted sessions, instructions from the beginning of context get de-prioritized as the window fills. Principles that worked in the first hour quietly stop working by hour three.

**How we adopted it:** Critical standing rules (quality gate, build order, test-alongside-code) are loaded via memory at session start, not buried in docs. For multi-sprint sessions, we start fresh conversations rather than extending stale ones. Compaction summaries preserve key rules.

**What it changed:** Explains why we've had more errors in late-session work (e.g., Sprint 6 integration test type mismatches happened deep into a long session). Reinforces our practice of starting fresh sessions for new sprints.

---

### L8: Project Rules Before Behavioral Principles

**Source:** Rezvani, A. (2026). Same article. "I ended up putting Karpathy's principles after my project-specific rules. Project rules establish what this codebase is, behavioral principles establish how to behave inside it."

**Problem it fixes:** When behavioral guidelines (be simple, be surgical) load before project-specific rules (use provider abstraction, tests alongside code, 22-point gate), the AI treats project rules as advisory rather than mandatory.

**How we adopted it:** Our standing rules already load first via memory. ENGINEERING_LEARNINGS.md is a reference doc, not a system prompt. This is the correct order. Standing rules > project conventions > general principles.

**What it changed:** Validates our current approach. No process change needed, but worth documenting why the order matters.

---

### L9: Living Documents Go Stale — Review at Phase Boundaries

**Source:** Rezvani article + Karpathy's own admission: "I had not figured out a good way to keep CLAUDE.md updated."

**Problem it fixes:** Engineering principles and standing rules accumulate but never get pruned. New conventions emerge, old rules become irrelevant or contradictory, and the gap between documentation and practice becomes its own source of bugs.

**How we adopted it:** ENGINEERING_LEARNINGS.md, GENAI_MANIFESTO.md, and standing rules are reviewed at every phase boundary as part of the N4 entry gate check. Stale entries are updated or removed. "Last updated" date tracked at bottom of file.

**What it changed:** Prevents documentation rot. Each phase boundary is a natural checkpoint to ask: "Is everything in this file still true?"

---

### L10: Claude.ai vs Claude Code — Know What Each Tool Costs You

**Source:** Our own workflow analysis after 7 sprints across Phase 2 (April 2026).

**Problem it fixes:** Choosing the wrong AI-assisted development workflow without understanding the tradeoffs. Both tools have real strengths; neither is strictly better.

**What Claude.ai costs us (friction):**

- **No autonomous file operations.** Every file edit requires generating scripts/patches, human copy-paste, and running manually. Claude Code reads/writes files directly in the repo.
- **No autonomous test-fix loops.** Claude Code runs tests, sees failures, fixes, re-runs until green — one pass. We do this across multiple messages. Sprint 6 integration tests took 4 fix rounds that Claude Code would have self-corrected.
- **No git operations.** We compose git commands, human pastes them. Zsh comment syntax (`#`) causes failures regularly. Claude Code branches, commits, pushes natively.
- **No live file reading.** Every type mismatch we hit (`MetricEvent.value` vs `.values`, `blocked` vs `matched`, `MemoryCacheProvider` vs `InMemoryCacheProvider`) happened because the AI couldn't read the actual file — it had to ask the human to run `grep`/`head`/`sed -n`.
- **Session context limits.** Long sessions get compacted. Context drifts. Standing rules weaken over time (see L7).

**What Claude.ai gives us (safety + depth):**

- **Human review on every change.** Nothing lands without verification. Zero regressions shipped to main across 7 sprints. Claude Code can make bad decisions autonomously at speed.
- **Architectural discussion.** Phase planning, RAMPS assessments, risk analysis (song ID costs/privacy), article analysis (Karpathy) — this depth of conversation doesn't happen naturally in Claude Code, which is biased toward "do this task."
- **Document generation.** ADRs, manifesto, sprint plans, ENGINEERING_LEARNINGS — Claude Code is weaker at long-form structured documents.
- **Cross-session memory.** Claude Code has CLAUDE.md but no memory of project history, preferences, or past decisions. Claude.ai carries context about the full project evolution.
- **Deliberate pace.** Every mistake gets caught before committing. The "A is for Accessibility" correction, the coverage regression flag, the middleware.ts sync collision — all caught because a human reviewed before applying.

**How we adopted it:** Continue using Claude.ai for planning, architecture, review, and document generation. If autonomous coding speed becomes a bottleneck, consider Claude Code for sprint execution with Claude.ai for oversight. The two tools are complementary, not competing.

**Future plan:** Evaluate hybrid workflow — Claude Code for mechanical coding tasks (file creation, test loops, git operations) under a CLAUDE.md that encodes our standing rules, with Claude.ai for architecture decisions, phase planning, and quality review. Not urgent — current workflow delivers reliably, just slower on mechanical steps.

---

### L11: Read Consumer Code Before Building Platform Abstractions

**Source:** Our own Phase 3 Sprint 2 experience (April 2026).

**Problem it fixes:** Building platform abstractions based only on PF's simplified code produces interfaces that are too narrow for the actual consumer. PF had 3 voice configs; Playform had 10. PF had no STT; Playform had full transcription with auto-detect.

**How we adopted it:** Before building any new PF module, always check Playform's implementation of the same feature. The consumer has the richer code — the abstraction must capture that full surface, not just PF's skeleton. Standing rule: "Read Playform before building PF abstraction."

**What it changed:** Sprint 2 voice provider was built to match Playform's full voice surface (10 languages, STT with auto-detect, content extraction routing) rather than PF's 3-language TTS-only skeleton.

---

### L12: The GenAI Mapping Table Is a Pre-Flight Checklist, Not a Planning Document

**Source:** Our own Phase 3 Sprint 3 near-miss (April 2026).

**Problem it fixes:** Skipping the 18-principle mapping table because "I already know the principles." Sprint 3's initial pipeline implementation missed P15-P18 entirely — the agentic principles. The pipeline was an autonomous agent acting on behalf of users, but had no agent identity, no cognitive memory, no intents, and no trajectories. The gap was only caught because the human asked "have we checked all our GenAI principles?" If not caught, the pipeline would have shipped non-agentic and required expensive retrofitting.

**How we adopted it:** The mapping table is now mandatory before any code, every sprint. It checks ALL 18 principles — not just the ones that feel relevant. The principles you skip are the ones that bite. Pilots don't skip the checklist because they've flown before. The value isn't in knowing the items — it's in forcing verification against the actual implementation.

**Standing rule:** Every sprint starts with a complete 18-principle mapping table. No exceptions. If a principle doesn't apply, mark it "—" with a reason. The table is the first output of the sprint, before any file is created.

---

### L13: Design for Agents Running Your Platform, Not Just On It

**Source:** Dharmesh Shah (simple.ai@dharmesh), "Why Agents Need Their Own Interface" (April 2026).

**Problem it fixes:** Exposing granular API endpoints and expecting agents to chain them together. An agent calling `/api/process`, `/api/stream`, `/api/extract`, `/api/tts` separately must reason about workflow, handle errors, retry stale data, and burn tokens re-discovering the orchestration logic every time. This is bad AUX (Agent User Experience).

**The insight:** There are two levels of agentic design:

1. **Agents running ON your platform** — agents can call your APIs. This is table stakes.
2. **Agents running your platform** — the platform exposes workflow-level tools that encapsulate complete workflows. One call = one complete workflow. The platform returns structured results with `nextActions` so agents know what's possible without reasoning from scratch.

**Example — bad AUX (current):**

```
Agent calls: /api/process → parse response → /api/tts → handle error → retry → /api/extract
Five API calls + all error handling per interaction. Agent reasons through it every time.
```

**Example — good AUX (target):**

```
Agent calls: /api/agent/process-content { intent: "translate", input: audio, targetLanguages: ["es"] }
Platform returns: { trajectory, results, nextActions: ["translate-more", "done"], cost }
```

**How we adopted it:** Added to Phase 5 planning as a first-class design goal. Created `docs/AUX_DESIGN.md` to capture the AUX surface before building it. Every new API endpoint is now evaluated against: "Could an agent call this as a single workflow, or does it require multi-call orchestration?"

**Standing rule:** Every endpoint designed from Phase 4 onward must have an AUX assessment: what would an agent need to call to accomplish this workflow in one shot? If the answer is "multiple endpoints + reasoning," design a workflow-level tool.

---

### L14: Pre-Flight Rule — Read Before Write, Every Time

**Source:** Phase 3, Sprint 4 Playform wiring — 6 consecutive failures in a single session.

**Problem it fixes:** Late in a long session, Claude begins making assumptions about file structure, import patterns, test directives, and type compatibility without reading the actual code. The result is a cascade of failures: wrong jest environment, missing mock signatures, incorrect type assertions, broken component wiring. Each fix introduces new assumptions that cause the next failure.

**The insight:** The root cause is always the same — writing code based on what Claude _remembers_ the file looks like, not what it _actually_ looks like. Memory degrades over long sessions (L7), but the pre-flight rule catches it regardless of session length.

**The rule — before creating or modifying ANY file, Claude must:**

1. **Read** an existing file of the same type in the target repo to verify patterns (test directives, import style, type compatibility, mock signatures)
2. **State** any assumptions being made
3. **Verify** the quality gate command includes coverage check

**Why this is L14 and not just L1 restated:** L1 says "state assumptions." L14 says "don't assume at all — read the file first." L1 is about honesty; L14 is about preventing the situation where assumptions are needed. Reading eliminates the assumption.

**How we adopted it:** Added as a permanent standing rule in the session handoff document and enforced from Phase 4 onward. Skipping any step is an L1/L7 violation. If late in a long session, this rule applies with MORE rigor, not less.

**Standing rule:** Before creating or modifying ANY file, read an existing file of the same type first. No exceptions. No "I remember what it looks like." Read it.

### L15: Adversarial Review — Three Hostile Personas, No LGTM Allowed

**Source:** Alireza Rezvani, "Claude Code Skills Field Report" (April 2026). Adversarial code reviewer skill with three forced personas.

**Problem it fixes:** Sustainability gates and checklists verify _presence_ of things (tests exist, coverage held, types pass). They do not force _hostile scrutiny_ — asking what breaks at 3am, whether a new hire can maintain this, or whether there is an injection vector. The Phase 3 Sprint 4 failure (6 consecutive failures on Playform wiring) would have been caught by a New Hire persona asking "can someone with no context understand how SpikeApp assembles its components?"

**The three personas (all mandatory, each MUST find at least one issue):**

1. **Saboteur** — what breaks in production at 3am? Race conditions, retries without idempotency, silent failures, unbounded collections, circuit breaker gaps.
2. **New Hire** — can someone with no context maintain this in six months? Variable names, function length, missing "why" comments, implicit coupling between modules, undocumented assumptions.
3. **Security Auditor** — OWASP top ten, then environment secrets. Input validation at every boundary, injection vectors, hardcoded credentials, CORS misconfigurations.

**Rules of engagement:**

- Each persona MUST surface at least one finding — no "LGTM" allowed
- Findings classified as BLOCK (must fix before merge), CONCERN (should fix, tracked), or NOTE (informational)
- Duplicate findings from two personas are promoted one severity level
- Final verdict: BLOCK / CONCERNS / CLEAN

**How we adopted it:** Added to sprint close process. Before any sprint closes, run the 3-persona adversarial review on the sprint's code. Especially critical for agent-to-agent interactions where edge cases hide in the communication paths.

**Standing rule:** Every sprint close includes a 3-persona adversarial review. No persona may return "LGTM."

### L16: The 30/60 Day Doc Freshness Rule

**Source:** Alireza Rezvani, "Claude Code Skills Field Report" (April 2026). 30-day audit, 60-day delete rule adapted for documentation.

**Problem it fixes:** L9 says "Living Documents Go Stale — Review at Phase Boundaries." But phase boundaries can be 2-4 weeks apart, and some docs drift between phases without anyone noticing. SERVICE_ACCOUNTS.md was not even in the expected directory when we looked for it. AUX_DESIGN.md was written in Phase 3 but will not be actively used until Phase 5 — by then it may be half-wrong. Staleness is time-based, not event-based.

**The rule:**

- Every doc in `docs/` must have a `_Last updated:` footer with a date.
- At every **sprint boundary**: scan for any doc not updated in 30+ days. Verify it is still accurate. Update the footer if confirmed current, or fix the content.
- At every **phase boundary**: flag any doc not updated in 60+ days for refresh. Docs that are 60+ days stale must be re-read and either updated to reflect current state or explicitly confirmed as still accurate with a new date.

**What this is NOT:** This is not an archiving or deletion rule. No doc is deleted based on age alone. The rule forces a freshness check, not a purge.

**How we adopted it:** Added to sprint documentation gate (D1-D7) and phase exit gate (E1-E15). The `_Last updated:` footer is the trigger — if it is missing, add it. If it is old, verify.

**Standing rule:** At sprint close, verify every doc with `_Last updated:` older than 30 days. At phase boundary, docs older than 60 days must be refreshed.

### L17: Module-Level Gotchas — Scar Tissue Where It Matters

**Source:** Alireza Rezvani, "Claude Code Skills Field Report" (April 2026). "The Gotchas section is the most valuable content in any skill."

**Problem it fixes:** Our gotchas are centralized in ENGINEERING_LEARNINGS.md (global patterns) and the session handoff "Things That Trip Us Up" (session-specific). Both are global. When Claude is writing a new test in `platform/social/`, the relevant gotcha — "jest.mock needs generateRequestId" — is buried in a global list, not visible in the module context. L14 (pre-flight rule) mitigates this by forcing a read of existing files, but a module-level gotchas section is more direct.

**The rule:**

- Each `platform/` module maintains a `## Gotchas` section at the bottom of its `index.ts` JSDoc or in a `GOTCHAS.md` file within the module folder.
- When a bug is found during development, the fix goes into:
  1. The **module-level** gotchas (if module-specific — e.g., "SentryErrorReporter requires @sentry/nextjs as peer dependency")
  2. The **global** ENGINEERING_LEARNINGS.md (if it is a cross-cutting pattern — e.g., "always mock generateRequestId")
- Module gotchas are the **first thing read** during pre-flight (L14). Before writing any code in a module, read its gotchas section.
- Gotchas grow over time. They are never pruned. Each entry includes: what broke, why, and the fix.

**How we adopted it:** Starting Phase 4, every new module (`platform/social/`, `platform/agents/`) ships with a Gotchas section from day one. Existing modules get gotchas sections added as bugs are encountered.

**Standing rule:** Every `platform/` module maintains a Gotchas section. Module-specific bugs go there first, global patterns go to ENGINEERING_LEARNINGS.md.

---

### L18: Visual Pre-Flight — Render Before Commit

**Source:** Phase 4 Sprint 1b maintenance (April 2026). Six visual bugs shipped to production that were all discoverable without running the app — black text on dark background, wrong icon direction, stale results on mode switch, hardcoded placeholder values, confusing label text, and a full-width UI element that looked interactive when it wasn't.

**Problem it fixes:** L14 (pre-flight rule) says "read before write." But L14 is about code patterns — import styles, type signatures, mock shapes. It does not cover visual outcomes. A component can pass typecheck, lint, 121 unit tests, and 86% coverage while being completely unusable because text is invisible on the consumer's background.

The root cause: every verification in the quality gate operates on code structure, not on what the user sees. Types compile ≠ text is readable. Tests pass ≠ buttons make sense. Coverage holds ≠ the UI isn't confusing.

**The rule — before committing any component or UI change, Claude must:**

1. **Walk through every visual state mentally:** What does the user see when the component mounts? When text is entered? When mode switches? When results arrive? When errors occur? On a light background? On a dark background?
2. **Check color values against the consumer's background:** If the component will render on `bg-slate-900`, are `text-gray-900` and `bg-gray-100` visible? "It has dark: variants" is not an answer — verify the activation mechanism.
3. **Check conditional UI:** When a mode changes, does stale content from the previous mode persist? Are default/fallback values meaningful or lazy placeholders?
4. **Check icon/label semantics:** Does an upload icon point up? Does "Spoken" next to a mic icon read as "you spoke this" or "conversational register"? Labels are read in context, not in isolation.
5. **State the visual outcome** in the assumptions block before creating the file: "User sees white text on dark card, placeholder is gray-500, inactive pills are gray-700."

**Why this is L18 and not just L14 extended:** L14 prevents code-level assumptions by reading existing files. L18 prevents visual-level assumptions by simulating the user's experience. You can follow L14 perfectly and still ship invisible text. L18 catches what L14 cannot.

**How we adopted it:** Added to the pre-flight process alongside L14. Every component change now includes a visual state walkthrough in the assumptions block. The THEMES map pattern (all color decisions in one constant, selected by variant prop) was adopted in AdaptiveInput as the reference implementation.

**Standing rule:** Before committing any UI change, walk through every visual state the user will encounter. "Tests pass" is not "users can see it."

---

### L19: Audit-Critical Writes Are Not Fire-and-Forget

**Source:** Phase 4, Sprint 3a — L15 adversarial review finding F1 (April 2026).

**Problem it fixes:** Config history writes were fire-and-forget (modeled after moderation audit). But config history IS the audit trail — its sole purpose is answering "who changed what and when." A silent failure defeats the entire feature. The admin sees "success" but there's an undetectable gap in the change history.

**The distinction:** Moderation audit (P11 fire-and-forget) and config history serve different roles:

- **Moderation audit**: The moderation decision (block/allow/warn) still applies regardless of whether the audit record persists. Fire-and-forget is correct — the primary function (content safety) is preserved.
- **Config history**: The history IS the primary function. Without it, there's no record of what changed, when, or why. Silent failure breaks the core promise.

**The test:** Before making any persistence call fire-and-forget, ask: "Does the caller need to know if this write failed?" If the answer is yes — if the write IS the feature, not a side effect of the feature — then await the result and surface failures.

**How we adopted it:** `writeConfigHistory()` changed from `Promise<void>` (fire-and-forget) to `Promise<{ success, error }>`. The caller (`setConfigWithHistory`) surfaces `historyWriteFailed: boolean` in its return type. Error logs include the full change payload so gaps are reconstructible from Sentry.

**Standing rule:** When adding a new persistence write, classify it: is it a side effect (fire-and-forget OK) or the primary function (must await and surface)? Document the classification in the JSDoc.

### L20: Mid-Session Context Checkpoint

**Source:** Phase 4, Sprint 5 -- Article review: Yazidi 2026 "14 Commands" (May 2026).

**Problem it fixes:** Error rates climb in the back half of long sessions. Context pressure builds, earlier file reads go stale, and pre-flight rigor relaxes precisely when it should tighten. The Claude Code /cost command gives CLI users a "fuel gauge" for context consumption. Our Claude.ai workflow has no equivalent checkpoint.

**The insight:** Claude Code's /compact (context compression) and /cost (context fuel gauge) solve the same problem we solve with handoff documents -- but within a single session. Our between-session discipline is strong (additive handoffs, pre-flight checklists). Our within-session discipline relies on L14's note that pre-flight "applies with MORE rigor late in long sessions," but this is aspirational without a concrete trigger.

**The rule:** After every 3 committed features within a single session, pause and:

1. Re-read the standing rules (Section 9 of the handoff).
2. Run the full quality gate (format, typecheck, lint, test, coverage).
3. Verify coverage has not dropped below the floor.
4. For the next file, apply L14-STRICT even if you think you remember the signatures.

This is the in-session equivalent of the between-session pre-flight checklist.

**How we adopted it:** Added as standing rule. First applied in Sprint 5 (3+ features in a single session building RAG pipeline).

**Standing rule:** After 3 committed features in one session, run the mid-session checkpoint before continuing.

---

### L21: Every Abstraction Ships a Conformance Kit

Every provider abstraction registered in `platform/providers/registry.ts` must
ship a **conformance kit** (`__tests__/contract/<x>-contract.ts`): a
provider-agnostic behavioral contract, parametrized by a fixtures adapter
(shared canonical inputs + impl-specific opaque values), run against the
reference/mock impl in a synced arm and against every concrete impl in its own
arm — consumer-owned for an abstraction a consumer reimplements (today
auth/Cognito), a single synced arm for PF-shipped real impls.

The convention is self-policing, not a remembered checklist: the registry-driven
meta-test `__tests__/contract/conformance-coverage.test.ts` walks
`getActiveProviders()` and fails CI if any registered slot has no kit in the
manifest. A new provider slot cannot land without one. See ADR-027.

Building the concrete arms is not ceremony. The first pass surfaced six
mock-biased contract assertions that both signature-level typing and per-impl
tests had missed: SSO redirect casing, two `expiresAt` ms-vs-epoch-seconds unit
splits, an optional MFA-setup session, an internally inconsistent challenge
`success` flag, and STT language normalization. The arm is the thing that proves
a real implementation actually satisfies the contract.

### L22: No Task Outlives Its Sprint

Every open task in `TASKS.md` and `SECURITY_DEBT.md` carries a **specific sprint**, not a
phase-shaped guess. "Phase 4+", "Phase 5+", "early sprint" are not schedules — they are
deferrals with no owner and no boundary, and work parked there rots invisibly.

**The gate:** a sprint cannot close while any open task is scheduled for a sprint or phase that
has **already ended**. Re-scope at the boundary or close it; do not let it drift.

Phase 5 Sprint 0 found eight open tasks still scheduled for Phase 4, Sprint 3c, and Sprint 4b —
sprints that had closed months earlier. Nothing anywhere flagged it. Two of them (an
unregistered health probe, a duplicated env-var read) were real defects sitting in the
registry, silently past due, because "Phase 4" stopped being a schedule the moment Phase 4
closed and no check noticed.

The same failure mode killed the Playform sync for two weeks (a rotated PAT, no alert) and
froze the module READMEs for a full phase (an unanchored rsync exclude). The pattern is
constant: **a system that fails silently fails indefinitely.** Make the boundary check
explicit, or the boundary does not exist.

### L23: Every Promotion to Main Carries a Written PR

No promotion to `main` merges on a bare title. Every PR uses
`.github/pull_request_template.md` and states, at minimum:

- **Summary** — one paragraph: what this delivers and why.
- **Changes** — module-level, grouped, not a file list.
- **Gate** — the actual result: suites, tests, coverage vs floor.

For any **fix**, additionally state the **root cause** and the **failure mode** — not just what
was changed. "SHA-pin the actions" is a diff; "mutable tags can be silently repointed by the
action owner, as in the trivy-action compromise" is the reason the diff exists. The PR body is
the durable record of _why_; six months on, the commit message will not tell you and neither
will the code.

The PR body is written for the person who has to understand this change after everyone has
forgotten it — including its author.

### Workflow Gotchas (32–47) — Phase 4 + Sprint 3c/3d Session Scar Tissue

> These are cross-cutting workflow issues, not module-specific (those go in module Gotchas sections per L17). They apply to every session regardless of which module is being built.

**32. Duplicate filenames in downloads.** Browser silently overwrites files with the same name. When downloading multiple files from Claude, prefix with module path: INPUT*, MOD*, PROV*, ADMIN*, PCONFIG*, ROUTE*, PROMPT*, MAINT*. Never use the same filename twice in a session.

**33. Sync reads from PF main, not develop.** Playform's sync config has `source_ref: "main"`. PRs must be merged ALL THE WAY TO MAIN before triggering Playform sync. Merging to develop or staging is not enough. This cost a full debug cycle in Phase 4 Sprint 2.

**34. Config-dependent code needs platform-config mock in tests.** Any code path reaching `getConfig()` calls `getSupabaseServiceClient()` without a mock. Every test file touching Guardian, middleware, safety, or config-agent code needs the platform-config mock. Symptom: "Cannot read properties of undefined (reading 'from')."

**35. git checkout discards uncommitted changes.** Switching branches without committing loses work. Maintenance fixes applied via sed/python but never committed were lost when switching to main. Always commit or stash before branch switching.

**36. sed with template literals fails.** Backticks and `${}` get mangled by shell escaping in heredocs and sed commands. For complex multi-line edits, use Python scripts or complete file replacements. Simple single-line sed is fine.

**37. git add -A picks up untracked files.** The wiki/ directory with 33 files was accidentally committed. Use explicit `git add <file1> <file2>` for targeted commits. Never use `git add -A` or `git add .` in these repos.

**38. Markdown auto-formatting on credential paste.** Pasting URLs or hostnames from rich-text sources (Notion, Apple Notes, Markdown docs) can inject `[text](url)` link syntax into shell variables and `.env` files. During TASK-026 rotation, `ACRCLOUD_HOST` was pasted as `[identify-us-west-2.acrcloud.com](http://...)` instead of the plain hostname. Always verify env files with `cat -A` or visual inspection before sourcing. Affects `.env` files, runbook-to-Vercel paste, any credential workflow.

**39. Never `cat` a credentials file in a shared/observed terminal.** This includes any session that is screen-shared, recorded, inside a chat assistant context, or captured by a clipboard history tool. During TASK-026 rotation, a broken verification command led to `cat` of a credentials file in chat, exposing the secret. Credentials had to be rotated again immediately. Use length-only and shape-only verification: `awk -F= '{print $1, "length:", length($2)}' creds.env`. For value inspection, use `cat -A` only when you control the entire output destination.

**41. Never copy-paste mocks to get green — shared mocks exist for a reason.** During Sprint 3d, adding auth guards to 6 routes produced 43 test failures. The fix was to copy-paste the same `jest.mock()` block into all 6 test files. This violates A5 (redundancy), B11 (missing edge case coverage), and creates a maintenance trap: if the mocked interface changes, 6 files break independently. The correct approach: Jest auto-mocks via `__mocks__/` directories for shared dependencies, plus per-route auth-denial tests that verify the guard is actually wired. "Get green" is not a goal — "get green correctly" is.

**40. Bash `&&` chaining breaks on `grep` no-match.** `grep` exits with code 1 when it finds no matches, which is the _clean_ result for a "no bad patterns present" check. Commands chained with `&&` silently halt at this exit code, making it look like the script failed when it actually succeeded. Use `;` separators for verification scripts where no-match is the expected clean state, or pipe through `|| true`.
**45. Trace the full request chain before adding auth to unauthenticated routes.** When adding server-side auth enforcement to previously unauthenticated routes, trace the FULL chain in one pass before the first commit: frontend fetch → auth header attachment → middleware → route guard → provider registration → mock provider token → E2E token alignment. Sprint 3d required 5 fix commits because each layer was discovered sequentially. Do not commit layer by layer.

**46. When CI fails, collect ALL diagnostic info in ONE pass.** Do not iterate one hypothesis at a time. Collect: provider name, token verification result, server startup logs, env vars, module import graph, E2E token values, mock provider constants. Then diagnose from complete information. Sprint 3d auth pipeline took 10+ CI cycles because each failure was debugged piecemeal.

**47. When patching files with Python scripts, read the exact target pattern from the actual file immediately before writing the replacement.** Never construct match patterns from memory or earlier reads — Prettier may have reformatted since the last read. Use `sed -n` or `grep` to capture the exact current content, then build the replacement from that. Sprint 3d had 5+ patch script failures from stale patterns.

**42. Side-effect imports bypass the provider registry.** During Sprint 3d, 9 auth routes had `import "@/platform/auth/cognito-config"` which auto-registered Cognito at module load time, before `initProviders()` ran. The registry's `if (hasAuthProvider()) return` guard meant mock provider never registered. Side-effect imports that mutate global state are invisible race conditions. Auth registration must only happen through `initProviders()` in `instrumentation.ts`. Never register providers via side-effect imports.

**43. Next.js production builds isolate module singletons.** `require()` in `instrumentation.ts` and `import` in route handlers may resolve to different module instances in production builds. A singleton set in one context is null in the other. Fix: `getAuthProvider()` uses lazy initialization — if the singleton is null, it calls `initProviders()` again. This is safe because `initProviders()` is idempotent (`if (initialized) return`).

**44. Mock provider IDs must pass the same validation as real IDs.** Account-status guard validates UUID format. Mock provider used `"mock-user-001"` which fails the regex. Changed to a valid UUID. Any guard that validates input format will reject test fixtures that use placeholder strings. Mock data must be realistic.

**80. The sync adds and updates but never deletes — a PF rename or removal orphans the old file in the consumer.** Sprint 3c split `app/api/admin/ai/handlers.ts` into a `handlers/` directory. The sync brought the new directory into Playform but left the old `handlers.ts` in place (deletion policy: manual removals only), and the stale file shadowed the directory — `@/app/api/admin/ai/handlers` resolved to `handlers.ts`, which lacked the new exports, and the production build failed with "export not found" while `tsc` and `jest` (which resolve differently) passed. The same class of orphan waits behind every rename, move, or delete PF makes. Rules: (1) after any PF refactor that renames, moves or deletes a file, list the sync branch's tree for the old path and `git rm` the orphan on the sync branch before merging — the diff-stat showing the new files is not confirmation the old one is gone; (2) a file and a directory of the same base name collide in module resolution, and the file wins, so the failure reads as "new code missing" rather than "old code present"; (3) extends Gotcha 33 — the sync's direction (from PF main) and its add-only nature are two separate facts, and this is the second.

**81. `useSearchParams`/`usePathname` need a Suspense boundary, and only `next build` catches the omission.** The U5 consent page used `useSearchParams()` without wrapping the client in `<Suspense>`. `tsc --noEmit` passed, the full `jest` suite passed, and dev mode rendered fine — then the production build failed to prerender `/agent/authorize` with a CSR-bailout error, surfacing only at Vercel after the merge. The constraint is a prerender-time property of the App Router, invisible to the type and unit gates. Rules: (1) any commit that adds or touches a page or route client component runs `npm run build` as part of its gate, not just `tsc` + `jest` — the build is the only gate that exercises prerendering; (2) a client component reading URL state is wrapped in `<Suspense>` at the page boundary from the first write, not retrofitted after CI; (3) sits alongside Gotcha 43 — both are production-build-only failures that the dev server and the test runner cannot see.

**82. Verify a tag resolves to the intended commit before pushing it or cutting the release.** Cutting v2.0.0, `git checkout main && git pull` fast-forwarded and the tag was created — but the documentation promotion had reached staging and not main, so main was an earlier state and the tag pinned the release to the pre-docs commit. The 2026-06-09 handoff flagged this exact failure as a candidate learning; it was never encoded, and it recurred. Rules: (1) after tagging and before pushing, assert the tag's content — `git show <tag>:package.json` for the version and `git log -1 <tag>` for the SHA must both be what you intend; (2) a green local `git pull` proves your local matches origin, not that the work you meant to release actually reached the branch you tagged — check what's on the branch, not that the pull succeeded; (3) a mis-placed tag is cheap to fix before the GitHub Release exists and expensive after, so verify in the gap between `git tag` and publishing.

**83. A `_Last updated:` footer that stays old on freshly-changed content is worse than no footer (L16 sharpening).** The docs-integrity test (added in Sprint 3c) asserts each architecture doc HAS a `_Last updated:` marker — a presence check, which an untouched-since-2026-04 footer passes while the doc's body is months out of date. When the arch-refresh added a whole governed-authority section to AGENT_ARCHITECTURE, the footer still read April until it was caught and updated in the same batch. Rules: (1) a commit that changes a doc's body updates that doc's footer date in the same commit — the machine can enforce the footer exists (L16), but only the author can keep its date honest; (2) a presence check is not a freshness check, and conflating them lets a stale doc show a green gate; (3) the footer's value is that it can be trusted, and one silently-stale date teaches readers to distrust all of them.

**84. A `let` reassigned only inside a closure keeps its initializer's narrowed type — hold step-shared state in an object, not captured `let`s.** In the ADR-039 runtime migrations (Sentinel, Guardian, Conductor), the decision logic moved into an `executeAgent` `WorkflowFn` closure that assigned results to outer `let`s (`let consequence = "none"; ...; workflow sets consequence = ...`). TypeScript's control-flow analysis narrows a captured `let` to its initializer at any use _after_ the closure — it cannot see the closure's reassignment — so `if (consequence === "block")` post-run raised `TS2367: "none" and "block" have no overlap`, and the value read back was the stale default at runtime too. Rules: (1) step-shared state a `WorkflowFn` writes and the caller reads lives in one mutable object (`const acc: {...} = {...}`) — object-property reads use the declared type and are not CFA-narrowed the way a captured `let` is; (2) the object also keeps those fields definitely-assigned for the post-run result without non-null assertions; (3) the tell is a `TS2367` "no overlap" on a union you know is reassigned — the compiler is reading the initializer, not the closure's write.

**85. Adding a member to an enumerated set (an agent, an ADR) trips hidden cardinality/roster assertions scattered across tests and docs — grep for them before packaging.** Registering Sentinel broke a hard-coded `expect(AGENT_CONFIGS).toHaveLength(8)`; reserving ADR-036/037/038 tripped docs-integrity's "TAD lists every ADR" check; each surfaced only when the gate ran on the human's machine — a wasted round trip. The counts and rosters that must move in lockstep are scattered: agent-count tests, `agent-registry-integrity.test.ts`, `docs/TAD.md`'s ADR index, `docs/README.md`'s ADR count, `AGENT_ARCHITECTURE`'s roster. Rules: (1) adding an agent → bump the `toHaveLength(` in the agent-config test and add it to `AGENT_ARCHITECTURE`'s roster (enforced by `agent-registry-integrity.test.ts`); (2) adding/reserving an ADR → add it to `docs/TAD.md` and bump `docs/README.md`, same commit; (3) whenever a change grows an enumerated set, grep the repo for that set's cardinality assertions before packaging — the sandbox catches it, but only if you run it, and grepping is cheaper than a round trip.

_Last updated: September 4, 2026 (Phase 5 Sprint 3c close — Gotchas 80-83 added; sync add-only orphans, useSearchParams needs Suspense, verify a tag before releasing, honest doc footers)_
_Last updated: September 7, 2026 (Phase 5 Sprint 3d — Gotchas 84-85 added; closure-narrowed lets need an acc object, and growing an enumerated set trips hidden count/roster assertions)_

## Noted (Not Yet Adopted)

_Entries here are interesting but haven't passed the "changes how we build" test yet._

<!-- Add future candidates here with source link + one sentence on why it might matter -->

### Yazidi 2026 "14 Commands" -- Validated by Existing Practices

The article describes 14 Claude Code CLI commands for productivity. Our Claude.ai workflow already covers every concept, often more rigorously:

| Article concept                    | Our equivalent                                                    | Assessment                                         |
| ---------------------------------- | ----------------------------------------------------------------- | -------------------------------------------------- |
| /init (auto-generate project docs) | Pre-flight checklist + additive handoff documents                 | Ours is more structured                            |
| /memory (persistent preferences)   | userMemories + standing rules in handoff                          | Ours persists across sessions with full context    |
| /compact (context compression)     | Additive handoff documents between sessions                       | Ours is more thorough -- full state reconstruction |
| /cost (context fuel gauge)         | **Gap identified** -- adopted as L20 mid-session checkpoint       | New rule added                                     |
| /review (systematic code review)   | L15 adversarial review (3 personas: Saboteur, New Hire, Security) | Ours is more rigorous                              |
| ! (run shell inline)               | Batched commands pasted by engineer                               | Different model, same intent                       |
| /model (switch models)             | Not applicable -- single model in Claude.ai                       | N/A                                                |
| /pr_comments (load PR context)     | PR titles/descriptions provided before every merge                | Same intent                                        |

**Verdict:** 1 of 14 concepts produced a new practice (L20). The remaining 13 validate existing workflow. No further action needed.

---

## Reading Queue

_Articles Raman has flagged for discussion. Processed entries move to "Adopted" or "Noted" above._

| Date       | Source                                                                                                                                      | Topic                                   | Status                                                                                                        |
| ---------- | ------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| 2026-04-13 | [Karpathy's CLAUDE.md analysis](https://alirezarezvani.medium.com/andrej-karpathys-claude-md-what-each-principle-really-fixes-20b159b4b582) | Four principles for LLM coding behavior | ✅ Processed → L1, L2, L3                                                                                     |
| 2026-03-26 | [The Agent-Native Rewrite](https://thesequence.substack.com/) (Rodriguez, Opinion #840)                                                     | Agent-native architecture vs bolt-on    | ✅ Processed → L5, P15-P18                                                                                    |
| 2026-04-18 | [Claude Code Skills Field Report](https://alirezarezvani.medium.com) (Rezvani)                                                              | Skills at small-team scale              | ✅ Processed → L15, L16, L17                                                                                  |
| 2026-04-19 | [Claude Code /powerup: 10 Built-In Lessons](https://alirezarezvani.medium.com) (Rezvani)                                                    | In-tool discoverability, effort tiers   | ✅ Noted → PHASE4_PLAN (4b effort tier), AGENT_ARCHITECTURE (Concierge UI constraint), AdaptiveInput tooltips |
| 2026-05-18 | [14 Commands That Changed Everything](https://medium.com) (Yazidi)                                                                          | Claude Code CLI productivity commands   | Processed: L20 (mid-session checkpoint); 13/14 validated by existing practices                                |

---

**48. After file placement + format, read exact content before next edit.** Prettier may collapse multi-line imports to single-line. Match patterns constructed from memory or the original file content will fail. Use `cat -n file | sed -n 'Xp'` to capture the exact current content. Sprint 4b had a fix script fail because Prettier collapsed a multi-line import pattern.

**49. Read exact function/property values before asserting in tests.** `DefaultIntentResolver.name` is `"default"`, not `"rule-based"`. `RuleBasedClassifier.name` is `"rule-based"`. Don't assume by analogy — `grep "name" file.ts` before writing expect(). Sprint 4b had a test failure from assuming resolvedBy would be "rule-based" when it was "default".

**50. Verify target directories exist before writing files.** `platform/input/` exists but `platform/input/__tests__/` may not. A heredoc to a nonexistent directory silently fails in zsh with no error on the `cat >` line — only later when the file is referenced. Always `mkdir -p` the exact target directory, not just the parent.

**51. Operator precedence: `??` is lower than `===`.** `(a ?? b === c)` evaluates as `(a ?? (b === c))`, not `((a ?? b) === c)`. Sprint 4b found a pre-existing bug where `(scopeId ?? scopeType === "platform")` always yielded `"platform"` when scopeId was defined, defeating per-group budget tracking. Always parenthesize mixed `??` and comparison operators.

**52. Never modify a PF-synced file in a consumer repo.** Fix in PF first OR add to sync excludes in same commit. Sprint close must verify. (Elevated from Sprint 4c error -- see handoff.)

**53. Display-layer corruption of method calls.** When pasting terminal output through chat interfaces, method calls like .map( get auto-linked as markdown URLs. The file on disk may be correct even when the displayed output looks corrupted. Always verify with `od -c` or `cat -A`, never visual inspection alone. Sprint 5 had 3 false-alarm cycles before od confirmed files were clean.

**54. Promise.race timer leak — always clearTimeout after the race.** `Promise.race([operation(), new Promise(resolve => setTimeout(resolve, timeout))])` leaves the setTimeout active when the operation wins, leaking a timer that keeps Jest workers alive. Store the timer and clear it: `let timer; const tp = new Promise(r => { timer = setTimeout(r, ms); }); const result = await Promise.race([op, tp]); clearTimeout(timer!);`. Sprint 6 traced a long-standing "worker failed to exit" warning to 14 leaked timers in hard-purge.ts.

**55. sed patterns must be unique — verify with `grep -c` before applying.** `sed 's/pattern/replacement/'` silently rewrites ALL matches. `export async function getQueue` matched both `getQueue` and `getQueueStats`, corrupting the file. Before any sed: `grep -c 'pattern' file`; if the count is > 1, the pattern is not unique — use line-targeted sed or FULL-REPLACE.

**56. Diagnose test-infrastructure issues systematically, not by hypothesis.** When Jest workers don't exit cleanly: (1) `--maxWorkers=1` to confirm it is a worker/handle issue, (2) `--detectOpenHandles` to find the leaked handle, (3) grep the source for `setTimeout`/`setInterval` lacking `.unref()`/`clearTimeout`. Don't guess at causes (Sentry globals, workerIdleMemoryLimit) — instrument.

**57. JSON columns from Supabase need `as unknown as TargetType`.** A direct cast from `Record<string, unknown>` to a typed interface fails TypeScript's overlap check. Cast through unknown: `row.json_col as unknown as MyType`. Every Supabase store mapper (incl. review-store moderation_result / explanation_chain) follows this.

**58. jest.mock is hoisted file-wide — you cannot mock a module AND exercise its real implementation in the same test file.** `jest.mock("@/x")` applies to the whole file regardless of where it is written, so a route test that mocks the service will also shadow the real service in that file's service tests (they then call the mock and return `undefined`). Split into two files: one mocks the module's dependencies and imports the real implementation; the other mocks the module to test its caller. Sprint 6 hit this with the combined review-assist test.

**59. zsh: backticks and bare globs in command arguments break the shell.** A backtick inside a `grep -E` pattern opens command substitution and drops you into a `dquote bquote>` continuation prompt (Ctrl-C to escape). An unquoted `--include=*.test.ts` errors with "no matches found". Single-quote glob and regex patterns; never put backticks in shell arguments — author files with create_file or a Python script instead (extends GOTCHA-36).

**60. The live DB has no migration-tracking table — never assume a PF migration applied.** The database was provisioned ad hoc, with no `supabase_migrations.schema_migrations` record per migration. A Sprint 6 audit found it was a partial, non-linear application of the set: 005 / 009 / 015 / 016 had never landed even though later migrations (017 / 018) had. PF migration history is not proof of live state. Before extending the schema, introspect the live DB (`information_schema.tables`/`columns`, `pg_policies`, `pg_proc`, `pg_trigger`) and reconcile by _object_, not by migration number.

**61. A `CREATE POLICY` against a non-existent table errors at creation — and then silently never applied.** Migration 009's RLS keyed on `public.profiles` (`profiles.role = 'super_admin'`), but PF's model is `public.users` + `roles` via `users.role_id` (post-008) — there is no `profiles` table. The policy failed to create on every DB, so 009 never applied and left no trace (no migration tracking to flag it). RLS policies must reference the actual schema model; this one was re-cast as a `service_role` policy with role gating at the API layer, matching the other server-side tables.

**62. `platform_config` seeds must supply every NOT NULL column and respect column types.** Migration 016's seed supplied only `(key, value, description, updated_by)`, but `category` / `value_type` / `permission_tier` are `NOT NULL` and `updated_by` is `UUID` (016 passed the text `'migration-016'`) — two independent failures, the type error firing first. Match the working 013/014 pattern: `(key, value, default_value, description, category, value_type, permission_tier)`. Note `value` is `JSONB`, so seeded numbers/arrays must be valid JSON (string literals are cast).

**63. Author git/shell sequences as scripts, and run `npm run format` inside them before committing.** Inline shell with single-quoted `-m` messages, `&&` chains, and special chars repeatedly trips the zsh rules (unmatched-quote `quote>` traps, comment `#`, parens). Extends Gotcha 59: every multi-step git/shell sequence is authored as a Python script (subprocess), where commit messages are argv strings with zero shell quoting. The script MUST run `npm run format` (then `format:check`) before `git add` / `commit` — script-authored edits otherwise bypass the formatter, the gate's first step, and CI `format:check` fails on the unformatted markdown. Never present a command and a "wait, fix" correction in the same breath — emit only the final correct command.

**64. An absence check must prove it can find something before its zero result counts.** A scanner that silently matches nothing is indistinguishable from a clean tree — both report success. Sprint 2's first hygiene scan shelled out with an unquoted `--include=*.ts`; zsh glob-expanded it, grep never ran, and the error text was counted as a match (Gotcha 59, recurring). That produced a false abort — noisy, but self-correcting. The dangerous polarity is the same bug in a check for _absence_: the broken scanner reports zero hits, the gate goes green, and the defects ship with a clean bill of health. Sprint 1 recorded exactly that outcome — realtime message ids logged as remediated when they were not, and two of three escaped template literals never recorded at all. Rules: (1) any check that passes by finding nothing must first assert a control string known to be present, in the same run and the same code path; (2) prefer in-process scanning over shelling out — every shell hop is a chance to silently scan nothing; (3) treat a scanner's error output as failure, never as data. Encoded in `__tests__/source-hygiene.test.ts`, whose first assertion is the self-test.

**65. Collapsing a switch into per-case closures moves the function-coverage denominator.** Sprint 2 step 1 replaced `dispatchConfigTool`'s ten-case switch with ten `execute` closures on the `CONFIG_TOOLS` literal (ADR-029 D1). Behaviour was identical and no line that had been covered became uncovered — but ten `case` labels inside one already-covered function became ten separately-counted functions, and only those the suite drives through `dispatchConfigTool` are covered. Function coverage fell 80.68 to 80.42 and statements 88.63 to 88.53, breaking both floors on a commit that changed no behaviour. The reflex when a floor breaks on a pure refactor is to read it as noise and adjust the floor; here the drop was real information — those closures genuinely had no direct coverage before, the switch had simply hidden that behind one function's hit count. Rule: any refactor that turns branches into callables (switch to handler map, if-chain to strategy objects, inline logic to closures on a registry literal) lands its coverage arms in the same commit. Read the drop as a denominator change and cover the new callables; never move the floor to meet it.

**66. A PostgREST fetch fake validates a store against itself, not against the schema.** The Supabase conformance arms in this repo fake `global.fetch` with an in-memory PostgREST that stores whatever keys the store sends and returns them. That genuinely exercises the store's URL building, filter construction, row mapping and retry loops — real value, and it is why the raw-fetch pattern was chosen over the JS client. But it cannot see the database. Migration 023 shipped a function referencing `agent_budgets.used_steps`, a column that does not exist (the table has `used_tokens`); the full gate was green, both kit arms passed, and it failed on the first real call. Column existence, column types, constraints, enum membership and function signatures are all outside what a fetch-level fake can assert, and the mismatch had been visible in an introspection dump earlier in the same sprint. Rules: (1) treat a Supabase arm as proving self-consistency, never schema conformance; (2) when a migration and a store are authored together, diff the migration's columns against the store's field names by hand before shipping — or automate it (TASK-067); (3) an introspection finding recorded mid-session is not carried forward by intention, only by writing it into the artifact that will act on it.

**67. Query `public.applied_migrations` before writing or applying a migration.** This database has no CLI-managed migration history, so for three phases "has migration N applied" was answerable only by introspecting objects and inferring. That produced a Sprint 6 audit wrong in both directions, two migrations that had never applied without anyone noticing, and three applied by hand in Sprint 2 with no record of any of them. Migration 025 creates `public.applied_migrations`; every migration from 025 onward records itself as its last statement, and `__tests__/migration-tracking.test.ts` fails if one does not. The backfill distinguishes `verified` (confirmed by introspection) from `assumed` (inferred from object presence, NOT evidence of application) from `absent` — do not read `assumed` as applied. Deliberately NOT `supabase_migrations.schema_migrations`: that is the Supabase CLI's table, and hand-populating it would make a future `db push` trust rows nobody verified.

**68. A pinned override can pin you to the vulnerable version.** `package.json` carried `"brace-expansion@5": "5.0.8"` — added when 5.0.8 was the fix for CVE-2026-14257. When GHSA-rgw5-rvv9-x895 landed saying 5.0.8 bypasses that mitigation, the override was actively holding the tree at the vulnerable version, and every attempt to move it appeared to fail. Adding a second, broader override (`"brace-expansion": "5.0.9"`) did nothing, because npm correctly prefers the more specific `name@major` form — which read as npm ignoring the override entirely. Roughly a day was lost to that misreading, and the existing entry was plainly visible in `package.json` the whole time: the diagnostic scripts read the overrides block but printed only the key they had just added. Rules: (1) when a version will not move, print the ENTIRE overrides block before theorising about the resolver; (2) an override is a claim that expires — the version that fixes today's advisory is a candidate for tomorrow's, so every override needs a task to remove it (TASK-069); (3) `npm ls <pkg>` labels overridden entries "overridden" even when your own change did nothing, so that label confirms an override is in play, not that yours is.

**69. Track every ADR decision from the moment the ADR is read, and report what a commit LEAVES as explicitly as what it does.** Sprint 2 mapped ADR-029's ten decisions to steps at the outset and never did the same for ADR-031's nine. The result: `ProposalRecord.observedVersion` shipped with a comment calling it "the stale-approval anchor (D5)" and nothing ever compared it; `VersionedState.producedBy` shipped as "the repair anchor" and nothing ever read it; an `EffectLedger` shipped that no production code called. Each commit message described what it did and was silent about what it walked past, so five decisions drifted and surfaced at the conformance step as though newly discovered. They were omissions being reported as discoveries. Rules: (1) on reading an ADR, write the decision-to-step ledger before writing code, for EVERY decision, not the ones the current step touches; (2) building an anchor for a decision without implementing it is a deferral, and a deferral is stated in the commit and filed as a task — never left implicit; (3) a commit message that lists only what was done is incomplete: what remains is part of the change's meaning; (4) an audit script whose probes you wrote confirms what you expected to find — its ABSENT results are trustworthy and its COMPLETE results are not, so probe for what would DISPROVE the decision, not for what would confirm it.

**70. A reserved ADR number is a number owed — record the reservation where the gate will look, at the moment it is claimed.** `docs/adr/` runs 029 → 031 because ADR-030 was reserved for AUX in the ROADMAP changelog that opened Phase 5, and ADR-031 was written first when Sprint 2 needed it. The reservation existed in one document and nowhere the exit gate reads, so it would have surfaced at E6 as an anomaly to investigate rather than a known state. Renumbering was never an option: ADR-031 is cited in about forty places, and breaking those citations to tidy a sequence is a worse outcome than the gap. Rules: (1) claiming a number in a plan, roadmap or changelog is a commitment, and the commitment is filed in TASKS.md the same session it is made; (2) prefer writing the ADR at the moment the number is claimed, even as a stub with its status and scope, over reserving against future work; (3) when a gate will encounter a deliberate anomaly, the anomaly is recorded in advance — a gate finding something unexplained costs an investigation, and this class of surprise is entirely avoidable. This is Gotcha 69 one level up: a decision left a trace in one place and nothing carried it to where it would be checked.

**71. Pin the formatter exactly — its version IS the check.** `format:check` asks whether the tree matches what this prettier would produce, so a floating version means a floating answer. PF pinned `^3.8.2` and Playform `^3.5.3`; they resolved to 3.8.2 and 3.9.6, and files formatted by one failed the other's check the moment a sync carried them across. TASK-059 recorded this as a version gap for two phases, which was the symptom — the cause was that NEITHER repo declared a version. Aligning the resolved versions would have fixed nothing, because the next `npm install` could move them apart again. The same reasoning applies to any dependency whose output is compared against a stored artifact: formatters, code generators, schema compilers, snapshot serialisers. It does NOT apply to ordinary libraries, where a caret is how security patches arrive — and note that `ajv` was pinned exactly for exactly this reason one sprint earlier, while prettier was left floating in the same file.

**72. A claim about state is a query, not a recollection.** Sprint 2 was declared complete three times and was not, each time because completion was asserted from memory of the work rather than read from the artifacts that record it. Every question that forced an actual look surfaced something: the documentation gate untouched, ADR-030 missing from the sequence, five task statuses still reading Open after being resolved, a TASK-069 cited in three commit messages and an assessment document that had never been created. None of these were subtle; all were one query away. The discipline that was already in place for edits — assert the anchor count, re-parse and verify the write landed — was simply not applied to claims, because a claim did not feel like an operation. Rules: (1) before stating that something is done, run the check that would prove it false; (2) `npm run sprint:check` exists for exactly this and its output is the answer, not a summary of it; (3) `__tests__/task-register-integrity.test.ts` makes the commonest version mechanical — a TASK id referenced anywhere in docs that has no entry now fails the suite, which would have caught the phantom TASK-069 the day it was first cited rather than three commits later.

**73. A fallback that never announces it fired turns a configuration failure into normal behaviour.** Every provider accessor in the platform returned a working in-memory default when nothing had been registered, and `tryGetObservability()` returned null with callers no-oping on it. Both were deliberate — fail soft, do not crash the app — and together they meant a completely unwired system was indistinguishable from a correctly configured one. `initProviders()` had been setting registry slots on a bundle copy no request ever read, so every route ran in-memory defaults regardless of `TRAJECTORY_STORE`, `BUDGET_STORE` and the rest; Sentry was configured and receiving nothing. It survived because five separate mechanisms each hid it: tests do not bundle so the pattern works under jest, the conformance kits verify the stores rather than the wiring, both fallbacks are silent, `/api/health` returned a hardcoded `"ok"`, and the durable stores were never switched on so in-memory was also the expected result. Rules: (1) a fallback that fires because configuration did not arrive is an error — warn at minimum, and distinguish "nothing was configured" from "something was configured and did not reach me"; (2) at least one test must run against the production bundle and assert that configuration took effect, because the environment where a singleton works is the one tests run in; (3) treat sustained silence from a telemetry sink as a signal, since an application that cannot report is also unable to report that it cannot.

**74. An identifier substitution that ignores string and comment boundaries will corrupt a log message, and nothing type-checks a log message.** Converting twenty singletons to the bundle-safe registry meant replacing every reference to a binding named `initialized` with `readInitialized()`. The transform skipped lines containing its own generated names and nothing else, so `logger.info("Platform providers initialized", …)` became `logger.info("Platform providers readInitialized()", …)`, and a doc comment took the same hit. TypeScript was clean, eslint was clean, prettier was clean; the only thing that caught it was a test asserting the exact message string. The general point is that a rename tool operating on text rather than syntax is safe only for identifiers it can prove are identifiers, and neither a string literal nor a comment can be distinguished by a word-boundary regex. Rules: (1) when substituting an identifier across a file, exclude string and comment regions explicitly, or use a tool that parses; (2) prefer a rename that changes the declaration and lets the type checker find the uses, over one that finds the uses itself; (3) assert exact log messages in tests for anything an operator will search for, since that assertion is the only mechanism that noticed here.

**75. A task's close condition is a query — run it before scheduling the task.** TASK-047 asked for `middleware.ts` to be renamed to `proxy.ts` and said "close when the rename is done, the gate is green, and the deprecation warning no longer appears". All three had been true since Sprint 1's cleanup batch. It was nonetheless carried through two sprints, retargeted to Sprint 3 with a written justification about its external clock, and only found to be complete when someone finally ran `ls`. TASK-041 and TASK-059 were the same: closed in fact, open in the register. Every one of these had a close condition expressible as one command. Rules: (1) when a task is triaged, retargeted or picked up, run its close condition first — a task whose Resolution section cannot be checked by a command is a task whose condition is too vague to be useful; (2) `__tests__/task-register-integrity.test.ts` verifies structure and cannot verify truth, so a structurally perfect register can still be wrong about every entry; (3) three stale entries in one sprint is a process signal, not three accidents — the register is the artifact the next sprint plans against, and planning against it costs real time when it lies.

**76. A survey's scope is part of its result — state it, or the result is a different claim than the one made.** Three surveys in one sprint reported a subset as though it were the whole. Conformance-kit coverage was inferred by matching module names against kit FILENAMES, concluding `platform/voice` had none when it has four; the fix was to read `CONFORMANCE_MANIFEST`, whose own header calls itself the single source of truth. Column parity was inferred with a regex over a fixed list of SQL types, missing every enum-typed column and reporting five stores as broken when all were correct. And `platform/input`'s importers were searched under `platform/` alone, producing a README that stated nothing imported a module five files in two repos import — including the hook the demo UI depends on. Each wasted a cycle; the third wrote a falsehood into a durable artifact, where a reader acting on it would have deleted a live surface. Rules: (1) name the authoritative source before surveying, and if none exists say so in the output rather than inferring silently; (2) a search scoped to a directory reports on that directory — write the scope into the finding, so `grep platform/` never becomes "nothing imports this"; (3) prefer the declaration over the proxy: manifests, interface files and registries exist precisely to be read, and every one of these three had a file that already held the answer.

**77. The commit that does the work updates the register — nobody else will.** Four open tasks turned out to be satisfied, and two of them, TASK-056 and TASK-074, had been completed hours earlier by commits in the same session that never touched their entries. Sprint 2 ended with five statuses stale for exactly the same reason. The pattern is not that the register drifts over months; it is that closing work and recording it closed are two actions, and the second is skipped because the first felt like completion. TASK-048 shows the cost compounding: it sat open for two months, was retargeted with a written justification about being the cheapest item available, and was already done — so the register caused planning effort on work that did not exist. Rules: (1) a commit that satisfies a close condition edits the task in the same commit, and the script asserts the status took (a bare `replace()` failed silently five times in Sprint 2); (2) when a task is picked up, run its close condition first — four of four picked up this sprint were already complete; (3) a close condition that cannot be expressed as a command is too vague to close against, and rewriting it is cheaper than the repeated rediscovery it causes.

**78. An accessor that takes an id need not return it — check the interface, not the call signature.** `TrajectoryStore.getById(trajectoryId)` takes the id as a string, but the `TrajectoryRecord` it returns has no `trajectoryId` field: the id lives one level down at `record.trajectory.trajectoryId`. Reading `rec.trajectoryId` therefore yields `undefined` rather than a type error, because the access is on an interface that simply lacks the property. The TASK-075a store round-trip failed on exactly this and presented as a broken Supabase arm — the row was in the database, correctly written, and the assertion was reading a field that does not exist. Four sibling stores return their id at top level (`proposalId`, `entryId`), which is what makes the asymmetry read as consistency. Rules: (1) when a call takes an id and the assertion on its result fails with `undefined`, suspect the shape of the result before suspecting the call; (2) read the returned interface's declaration rather than inferring its fields from the argument list — this is Gotcha 76's "prefer the declaration over the proxy" applied to a type; (3) Sprint 3b's agent-native contracts expose trajectory identity to callers, which is the next place this shape will bite.

_Last updated: August 14, 2026 (Phase 5 Sprint 3b — Gotcha 78 added; an accessor that takes an id need not return it)_
_Last updated: August 11, 2026 (Phase 5 Sprint 3a — Gotcha 77 added; the commit that does the work updates the register)_
_Last updated: August 4, 2026 (Phase 5 Sprint 2 — Gotcha 71 added; pin the formatter exactly, its version is the check)_
_Last updated: August 4, 2026 (Phase 5 Sprint 2 — Gotcha 70 added; a reserved ADR number is a number owed, recorded where the gate will look)_

**79. A route added to `collectCoverageFrom` without a test is a silent floor breach — and a piped gate hides it.** Sprint 3b's endpoint commit added `app/api/agent/process-content/route.ts` and `.../capabilities/route.ts` to the covered set with zero tests (both 0%), dropping Playform develop from 89.91% to 88.88% — below the 89.45% floor — while the two `lib/agent-*` files it shipped alongside were fully covered. The handoff still recorded 3b as "all green". The drag was invisible because the aggregate only moves a point and no single command was checking it at commit time. It compounded once: a fix-script ran `npx jest 2>&1 | tail -6` and checked the pipeline's exit code — `tail`'s 0, not jest's — so a run with one failing suite reported OK and committed on red. Rules: (1) a source file added to `collectCoverageFrom` lands in the SAME commit as its test, or the floor moves under you; (2) never pipe a gate command whose exit code you are checking — `cmd | tail` returns tail's status; redirect to a file and read it, or check `cmd` alone; (3) "all green" in a handoff is a claim to re-run, not a fact to inherit — the baseline-vs-current coverage diff is one command and settles it.

_Last updated: August 18, 2026 (Phase 5 Sprint 3b close — Gotcha 79 added; a route in collectCoverageFrom without a test is a silent floor breach)_

## The capability contract (ADR-030 D9) — integrator seam

Any consumer of platform-foundation (Playform is one) governs agent workflows through the
capability seam, not by editing the loop:

- A workflow declares an opaque `requiredCapability` name in its `WorkflowDefinition`.
- The consumer supplies `checkCapability(name, actor) => Promise<boolean>` in `RunGoalArgs`,
  resolving the name against ITS OWN permission model. PF never learns the consumer's
  permission strings.
- The loop checks up front: undeclared -> runs (state `none`); declared + true -> runs
  (`granted`); declared + false, OR no callback supplied -> denied, nothing runs, trajectory
  `failed`. Fail-closed: a governed workflow with no checker is denied, never run ungoverned.
- Every outcome is on `AgentResponse.capabilityCheck` (`none` is a value, not an absence) so
  the consumer logs all three states and a discovering agent sees denials in-band.

A third-party integrator therefore needs only: name capabilities on their workflows, and
supply one callback. The admin UI to define capabilities and edit the mapping is Sprint 3c.
