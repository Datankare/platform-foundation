"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  ADMIN_HIGHLIGHT_DURATION_SECONDS,
  ADMIN_HIGHLIGHT_MIN_SECONDS,
  ADMIN_HIGHLIGHT_MAX_SECONDS,
} from "@/shared/config/limits";

const thClass =
  "text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800";
const tdClass = "py-3 px-4 text-gray-300 border-b border-gray-800/50";

function clampHighlight(seconds: number): number {
  return Math.max(
    ADMIN_HIGHLIGHT_MIN_SECONDS,
    Math.min(ADMIN_HIGHLIGHT_MAX_SECONDS, seconds)
  );
}

function DataTable({
  headers,
  children,
  emptyMessage,
  isEmpty,
}: {
  headers: string[];
  children: React.ReactNode;
  emptyMessage: string;
  isEmpty: boolean;
}) {
  return (
    <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
      <table className="w-full text-sm text-left border-collapse">
        <thead>
          <tr>
            {headers.map((h) => (
              <th key={h} className={thClass}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
      {isEmpty && (
        <p className="text-center text-gray-500 py-8 text-sm">{emptyMessage}</p>
      )}
    </div>
  );
}

function useHighlight(
  ids: string[],
  durationSeconds: number = ADMIN_HIGHLIGHT_DURATION_SECONDS
): Set<string> {
  const [highlighted, setHighlighted] = useState<Set<string>>(new Set());
  const prevIdsRef = useRef<string | null>(null);
  const clamped = clampHighlight(durationSeconds);

  const idsKey = ids.join(",");

  useEffect(() => {
    // First render: record IDs without highlighting
    if (prevIdsRef.current === null) {
      prevIdsRef.current = idsKey;
      return;
    }

    // No change
    if (idsKey === prevIdsRef.current) return;

    const prevSet = new Set(prevIdsRef.current.split(",").filter(Boolean));
    const newIds = ids.filter((id) => !prevSet.has(id));
    prevIdsRef.current = idsKey;

    if (newIds.length > 0) {
      setHighlighted(new Set(newIds));
      const timer = setTimeout(() => setHighlighted(new Set()), clamped * 1000);
      return () => clearTimeout(timer);
    }
  }, [idsKey, ids, clamped]);

  return highlighted;
}

/* eslint-disable @typescript-eslint/no-explicit-any */

// ── Roles Data View with Drill-Down ─────────────────────────────────────

interface RolePermission {
  code: string;
  displayName: string;
  category: string;
}

export function RolesDataView({ data }: { data: any }) {
  const roles = data?.roles || [];
  const [expandedRole, setExpandedRole] = useState<string | null>(null);
  const highlighted = useHighlight(roles.map((r: any) => r.id));

  if (roles.length === 0) {
    return (
      <p className="text-gray-500 text-sm">
        No roles found. Use the command bar to create one.
      </p>
    );
  }

  return (
    <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
      <table className="w-full text-sm text-left border-collapse">
        <thead>
          <tr>
            <th className={thClass}>Role</th>
            <th className={thClass}>Display Name</th>
            <th className={thClass}>Permissions</th>
            <th className={thClass}>Created</th>
            <th className={thClass}>Modified</th>
          </tr>
        </thead>
        <tbody>
          {roles.map((r: any) => {
            const isExpanded = expandedRole === r.id;
            const isHighlighted = highlighted.has(r.id);
            return (
              <React.Fragment key={r.id}>
                <tr
                  onClick={() => setExpandedRole(isExpanded ? null : r.id)}
                  className={`cursor-pointer transition-colors ${
                    isHighlighted
                      ? "bg-green-900/30"
                      : isExpanded
                        ? "bg-blue-900/10"
                        : "hover:bg-gray-800/30"
                  }`}
                >
                  <td className={tdClass}>
                    <code className="text-xs">{r.name}</code>
                  </td>
                  <td className={tdClass}>{r.displayName}</td>
                  <td className={tdClass}>
                    <span className="text-blue-400 cursor-pointer">
                      {r.permissionCount}{" "}
                      <span className="text-xs text-gray-500">
                        {isExpanded ? "▲" : "▼"}
                      </span>
                    </span>
                  </td>
                  <td className={`${tdClass} text-xs text-gray-500`}>
                    {r.createdAt ? new Date(r.createdAt).toLocaleDateString() : "—"}
                  </td>
                  <td className={`${tdClass} text-xs text-gray-500`}>
                    {r.updatedAt ? new Date(r.updatedAt).toLocaleDateString() : "—"}
                  </td>
                </tr>
                {isExpanded && (
                  <tr>
                    <td colSpan={5} className="px-4 py-3 bg-[#0d1320]">
                      {r.description && (
                        <p className="text-xs text-gray-500 mb-3">{r.description}</p>
                      )}
                      {r.permissions && r.permissions.length > 0 ? (
                        <div className="grid grid-cols-2 gap-2">
                          {r.permissions.map((p: RolePermission) => (
                            <div key={p.code} className="flex items-center gap-2 text-xs">
                              <span className="text-green-400">✓</span>
                              <code className="text-gray-400">{p.code}</code>
                              <span className="text-gray-600">{p.displayName}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-gray-600">No permissions assigned.</p>
                      )}
                      <div className="mt-3 text-xs text-gray-600 flex gap-4">
                        <span>
                          Created:{" "}
                          {r.createdAt ? new Date(r.createdAt).toLocaleString() : "—"}
                        </span>
                        <span>
                          Modified:{" "}
                          {r.updatedAt ? new Date(r.updatedAt).toLocaleString() : "—"}
                        </span>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Users Data View ───────────────────────────────────────────────────

export function UsersDataView({ data }: { data: any }) {
  const users = data?.users || [];
  const highlighted = useHighlight(users.map((p: any) => p.id));

  return (
    <DataTable
      headers={["Email", "Display Name", "Role", "Created"]}
      isEmpty={users.length === 0}
      emptyMessage="No users found."
    >
      {users.map((p: any) => (
        <tr
          key={p.id}
          className={highlighted.has(p.id) ? "bg-green-900/30 transition-colors" : ""}
        >
          <td className={tdClass}>{p.email || "—"}</td>
          <td className={tdClass}>{p.displayName || "—"}</td>
          <td className={tdClass}>{p.roleName}</td>
          <td className={tdClass}>{new Date(p.createdAt).toLocaleDateString()}</td>
        </tr>
      ))}
    </DataTable>
  );
}

// ── Entitlements Data View ──────────────────────────────────────────────

export function EntitlementsDataView({ data }: { data: any }) {
  const groups = data?.groups || [];
  const highlighted = useHighlight(groups.map((g: any) => g.id));

  return (
    <DataTable
      headers={["Code", "Name", "Users", "Status"]}
      isEmpty={groups.length === 0}
      emptyMessage="No entitlement groups. Use the command bar to create one."
    >
      {groups.map((g: any) => (
        <tr
          key={g.id}
          className={highlighted.has(g.id) ? "bg-green-900/30 transition-colors" : ""}
        >
          <td className={tdClass}>
            <code className="text-xs">{g.code}</code>
          </td>
          <td className={tdClass}>{g.displayName}</td>
          <td className={tdClass}>{g.userCount}</td>
          <td className={tdClass}>
            <span
              className={`text-xs px-2 py-0.5 rounded ${
                g.isActive
                  ? "bg-green-900/30 text-green-400"
                  : "bg-gray-700 text-gray-400"
              }`}
            >
              {g.isActive ? "Active" : "Inactive"}
            </span>
          </td>
        </tr>
      ))}
    </DataTable>
  );
}

// ── Audit Data View ─────────────────────────────────────────────────────

export function AuditDataView({ data }: { data: any }) {
  const entries = data?.entries || [];
  return (
    <DataTable
      headers={["Time", "Action", "Actor", "Details"]}
      isEmpty={entries.length === 0}
      emptyMessage="No audit entries found."
    >
      {entries.map((e: any) => (
        <tr key={e.id}>
          <td className={`${tdClass} text-xs`}>
            {new Date(e.createdAt).toLocaleString()}
          </td>
          <td className={tdClass}>
            <code className="text-xs">{e.action}</code>
          </td>
          <td className={`${tdClass} text-xs`}>{e.actorId?.slice(0, 8) || "—"}</td>
          <td className={`${tdClass} text-xs text-gray-500 max-w-xs truncate`}>
            {e.details}
          </td>
        </tr>
      ))}
    </DataTable>
  );
}

// ── Config Views ────────────────────────────────────────────────────────

function ConfigRow({
  label,
  value,
}: {
  label: string;
  value: string | number | boolean;
}) {
  const display = typeof value === "boolean" ? (value ? "✓" : "✕") : String(value);
  return (
    <div className="flex justify-between">
      <span className="text-gray-400">{label}</span>
      <span className="text-white font-mono">{display}</span>
    </div>
  );
}

export function GuestConfigDataView({ data }: { data: any }) {
  const config = data?.config;
  if (!config) return <p className="text-gray-500 text-sm">Loading...</p>;
  return (
    <div className="bg-[#111827] rounded-xl border border-gray-800 p-5 max-w-lg">
      <div className="space-y-3 text-sm">
        <ConfigRow label="Nudge after sessions" value={config.nudgeAfterSessions} />
        <ConfigRow label="Grace after sessions" value={config.graceAfterSessions} />
        <ConfigRow label="Lockout after sessions" value={config.lockoutAfterSessions} />
        <ConfigRow label="Guest token TTL (hours)" value={config.guestTokenTtlHours} />
      </div>
    </div>
  );
}

export function PasswordPolicyDataView({ data }: { data: any }) {
  const policy = data?.policy;
  if (!policy) return <p className="text-gray-500 text-sm">Loading...</p>;
  return (
    <div className="bg-[#111827] rounded-xl border border-gray-800 p-5 max-w-lg">
      <div className="space-y-3 text-sm">
        <ConfigRow label="Min length" value={policy.minLength} />
        <ConfigRow label="Rotation (days)" value={policy.rotationDays} />
        <ConfigRow label="History count" value={policy.passwordHistoryCount} />
        <ConfigRow label="Uppercase" value={policy.requireUppercase} />
        <ConfigRow label="Lowercase" value={policy.requireLowercase} />
        <ConfigRow label="Number" value={policy.requireNumber} />
        <ConfigRow label="Special char" value={policy.requireSpecial} />
      </div>
    </div>
  );
}

export function PlatformConfigDataView({
  data,
}: {
  data: {
    entries?: {
      key: string;
      value: unknown;
      description: string | null;
      category: string;
      updatedAt: string;
    }[];
  };
}) {
  if (!data.entries) return <p className="text-gray-400">Loading...</p>;
  if (data.entries.length === 0)
    return <p className="text-gray-400">No config entries found</p>;

  // Group by category
  type ConfigEntries = NonNullable<typeof data.entries>;
  const grouped: Record<string, ConfigEntries> = {};
  for (const entry of data.entries) {
    if (!grouped[entry.category]) grouped[entry.category] = [];
    grouped[entry.category].push(entry);
  }

  return (
    <div className="space-y-6">
      {Object.entries(grouped).map(([category, entries]) => (
        <div key={category}>
          <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wide mb-2">
            {category}
          </h3>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-gray-400 border-b border-gray-700">
                <th className="text-left py-1 pr-4">Key</th>
                <th className="text-left py-1 pr-4">Value</th>
                <th className="text-left py-1">Description</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => (
                <tr
                  key={entry.key}
                  className="border-b border-gray-800 hover:bg-gray-800/50"
                >
                  <td className="py-2 pr-4 font-mono text-blue-300">{entry.key}</td>
                  <td className="py-2 pr-4 font-mono">
                    {typeof entry.value === "string"
                      ? entry.value
                      : JSON.stringify(entry.value)}
                  </td>
                  <td className="py-2 text-gray-400">{entry.description || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}

// ── Agent governance (Sprint 3c U4/U6) ──────────────────────────────────

/* eslint-disable @typescript-eslint/no-explicit-any */

export function TrustedAgentsDataView({ data }: { data: any }) {
  const pairs: [string, any][] = Array.isArray(data?.agents) ? data.agents : [];
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-6">Trusted agents</h2>
      {pairs.length === 0 ? (
        <p className="text-gray-500 text-sm">No agents registered.</p>
      ) : (
        <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
          <table className="w-full text-sm text-left border-collapse">
            <thead>
              <tr>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Agent
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Owner
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Scope
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Status
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Token ceiling
                </th>
              </tr>
            </thead>
            <tbody>
              {pairs.map(([id, rec]) => (
                <tr key={id}>
                  <td className="py-3 px-4 text-gray-200 border-b border-gray-800/50 font-mono text-xs">
                    {id}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {rec.owner}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {(rec.scopes || []).join(", ")}
                  </td>
                  <td className="py-3 px-4 border-b border-gray-800/50">
                    <span
                      className={
                        rec.status === "active" ? "text-green-400" : "text-red-400"
                      }
                    >
                      {rec.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {rec.maxTokenTtl ? `${rec.maxTokenTtl}s` : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function PerAccountRestrictionsDataView({ data }: { data: any }) {
  const rows: any[] = Array.isArray(data?.restrictions) ? data.restrictions : [];
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-6">Per-account feature control</h2>
      {rows.length === 0 ? (
        <p className="text-gray-500 text-sm">No per-account blocks in effect.</p>
      ) : (
        <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
          <table className="w-full text-sm text-left border-collapse">
            <thead>
              <tr>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  User
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Blocked feature
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Reason
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  By
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i}>
                  <td className="py-3 px-4 text-gray-200 border-b border-gray-800/50">
                    {r.user_id}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50 font-mono text-xs">
                    {r.feature}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {r.reason || "—"}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {r.created_by}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Approval policy (U1) + Capabilities (U2, read-only) ─────────────────

/* eslint-disable @typescript-eslint/no-explicit-any */

export function ApprovalPolicyDataView({ data }: { data: any }) {
  const policy = data?.policy;
  const rules: any[] = Array.isArray(policy?.rules) ? policy.rules : [];
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-6">Approval policy</h2>
      {!policy ? (
        <p className="text-gray-500 text-sm">No policy loaded.</p>
      ) : (
        <>
          <p className="text-sm text-gray-400 mb-4">
            Version {policy.version} · default approver:{" "}
            <span className="text-gray-200">{policy.default}</span>
          </p>
          {rules.length === 0 ? (
            <p className="text-gray-500 text-sm">
              No rules — the default approver handles every action.
            </p>
          ) : (
            <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
              <table className="w-full text-sm text-left border-collapse">
                <thead>
                  <tr>
                    <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                      Max risk
                    </th>
                    <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                      Effects
                    </th>
                    <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                      Required approver
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rules.map((r, i) => (
                    <tr key={i}>
                      <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                        {r.maxRisk}
                      </td>
                      <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                        {(r.effects || []).join(", ") || "any"}
                      </td>
                      <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                        {r.requiredApprover}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export function CapabilitiesDataView({ data }: { data: any }) {
  const goals: any[] = Array.isArray(data?.goals) ? data.goals : [];
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-2">Capabilities</h2>
      <p className="text-sm text-gray-500 mb-6">
        Read-only. Capabilities are derived from the registered workflows, not
        administered here.
      </p>
      {goals.length === 0 ? (
        <p className="text-gray-500 text-sm">No capabilities registered.</p>
      ) : (
        <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
          <table className="w-full text-sm text-left border-collapse">
            <thead>
              <tr>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Goal
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Endpoint
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Steps
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Est. cost
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Requires
                </th>
              </tr>
            </thead>
            <tbody>
              {goals.map((g, i) => (
                <tr key={i}>
                  <td className="py-3 px-4 text-gray-200 border-b border-gray-800/50 font-mono text-xs">
                    {g.goal}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50 font-mono text-xs">
                    {g.endpoint}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {(g.steps || []).map((s: any) => s.intent).join(" → ")}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    ${(g.estimatedCostUSD ?? 0).toFixed(4)}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {g.requiredCapability || "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Capability→feature mapping (U3) ─────────────────────────────────────

/* eslint-disable @typescript-eslint/no-explicit-any */

export function CapabilityMappingDataView({ data }: { data: any }) {
  const pairs: [string, string[]][] = Array.isArray(data?.mappings) ? data.mappings : [];
  return (
    <div>
      <h2 className="text-xl font-bold text-white mb-6">Capability → feature mapping</h2>
      {pairs.length === 0 ? (
        <p className="text-gray-500 text-sm">No mappings configured.</p>
      ) : (
        <div className="bg-[#111827] rounded-xl border border-gray-800 overflow-hidden">
          <table className="w-full text-sm text-left border-collapse">
            <thead>
              <tr>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Capability
                </th>
                <th className="text-xs text-gray-400 uppercase tracking-wider py-3 px-4 border-b border-gray-800">
                  Required features
                </th>
              </tr>
            </thead>
            <tbody>
              {pairs.map(([cap, feats]) => (
                <tr key={cap}>
                  <td className="py-3 px-4 text-gray-200 border-b border-gray-800/50 font-mono text-xs">
                    {cap}
                  </td>
                  <td className="py-3 px-4 text-gray-300 border-b border-gray-800/50">
                    {(feats || []).join(", ")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
