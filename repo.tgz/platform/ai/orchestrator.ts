/**
 * platform/ai/orchestrator.ts — Central LLM orchestration layer
 *
 * ADR-015: Every AI call goes through this orchestrator.
 * Provides: model tiering, circuit breaker, retry, instrumentation.
 *
 * Usage:
 *   const orchestrator = createOrchestrator();
 *   const response = await orchestrator.complete(request, {
 *     useCase: "safety-classify",
 *     requestId: "abc123",
 *   });
 *
 *   // Streaming (Sprint 5):
 *   for await (const chunk of orchestrator.stream(request, opts)) {
 *     process.stdout.write(chunk.text);
 *   }
 */

import {
  AIProvider,
  AIRequest,
  AIResponse,
  AIStreamChunk,
  AIStreamOptions,
  CircuitState,
  CircuitBreakerConfig,
  DEFAULT_CIRCUIT_BREAKER_CONFIG,
  OrchestratorOptions,
  AICallMetrics,
} from "./types";
import { AnthropicProvider, AIProviderError } from "./provider";
import { estimateCost, recordMetrics } from "./instrumentation";
import { logger } from "@/lib/logger";
import { getSingleton, setSingleton } from "@/platform/kernel/singleton";

// ---------------------------------------------------------------------------
// Circuit breaker
// ---------------------------------------------------------------------------

export class CircuitBreaker {
  private state: CircuitState = "closed";
  private failureCount = 0;
  private successCount = 0;
  private lastFailureTime = 0;
  private readonly config: CircuitBreakerConfig;

  constructor(config: CircuitBreakerConfig = DEFAULT_CIRCUIT_BREAKER_CONFIG) {
    this.config = config;
  }

  /** Check if the circuit allows a request through */
  canExecute(): boolean {
    if (this.state === "closed") return true;

    if (this.state === "open") {
      const elapsed = Date.now() - this.lastFailureTime;
      if (elapsed >= this.config.recoveryTimeMs) {
        this.state = "half-open";
        this.successCount = 0;
        return true;
      }
      return false;
    }

    // half-open: allow through for probing
    return true;
  }

  /** Record a successful call */
  recordSuccess(): void {
    if (this.state === "half-open") {
      this.successCount++;
      if (this.successCount >= this.config.halfOpenSuccessThreshold) {
        this.state = "closed";
        this.failureCount = 0;
        this.successCount = 0;
      }
      return;
    }
    // In closed state, reset failure count on success
    this.failureCount = 0;
  }

  /** Record a failed call */
  recordFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.state === "half-open") {
      // Any failure in half-open reopens immediately
      this.state = "open";
      return;
    }

    if (this.failureCount >= this.config.failureThreshold) {
      this.state = "open";
      logger.warn("Circuit breaker opened — AI provider failures exceeded threshold", {
        failureCount: this.failureCount,
        threshold: this.config.failureThreshold,
      });
    }
  }

  /** Get current circuit state — for monitoring and tests */
  getState(): CircuitState {
    // Re-evaluate open → half-open transition
    if (this.state === "open") {
      const elapsed = Date.now() - this.lastFailureTime;
      if (elapsed >= this.config.recoveryTimeMs) {
        return "half-open";
      }
    }
    return this.state;
  }

  /** Reset the circuit breaker — used in tests */
  reset(): void {
    this.state = "closed";
    this.failureCount = 0;
    this.successCount = 0;
    this.lastFailureTime = 0;
  }
}

// ---------------------------------------------------------------------------
// Orchestrator
// ---------------------------------------------------------------------------

export interface Orchestrator {
  /** Send a completion request through the orchestration layer */
  complete(request: AIRequest, options: OrchestratorOptions): Promise<AIResponse>;

  /**
   * Stream a completion response through the orchestration layer.
   * Instrumented with time-to-first-token, total tokens, and cost.
   * Falls back to complete() if the provider doesn't support streaming.
   *
   * @yields AIStreamChunk — text fragments with done/usage on final chunk
   */
  stream(
    request: AIRequest,
    options: OrchestratorOptions,
    streamOptions?: AIStreamOptions
  ): AsyncIterable<AIStreamChunk>;

  /** Get circuit breaker state — for monitoring */
  getCircuitState(): CircuitState;
  /** Reset circuit breaker — for tests */
  resetCircuit(): void;
}

export interface CreateOrchestratorOptions {
  /** Primary LLM provider — defaults to AnthropicProvider */
  provider?: AIProvider;
  /** Circuit breaker config — defaults to DEFAULT_CIRCUIT_BREAKER_CONFIG */
  circuitBreakerConfig?: CircuitBreakerConfig;
}

export function createOrchestrator(options?: CreateOrchestratorOptions): Orchestrator {
  const provider = options?.provider ?? new AnthropicProvider();
  const circuitBreaker = new CircuitBreaker(options?.circuitBreakerConfig);

  return {
    async complete(request: AIRequest, opts: OrchestratorOptions): Promise<AIResponse> {
      // Apply tier override if specified
      const effectiveRequest = opts.tierOverride
        ? { ...request, tier: opts.tierOverride }
        : request;

      // Circuit breaker check
      if (!circuitBreaker.canExecute()) {
        const error = new AIProviderError(
          "Circuit breaker is open — AI provider is unavailable",
          "transient"
        );
        recordFailureMetrics(effectiveRequest, opts, 0, error.message);
        throw error;
      }

      const startTime = Date.now();

      try {
        const response = await provider.complete(effectiveRequest);
        const latencyMs = Date.now() - startTime;

        circuitBreaker.recordSuccess();

        // Record success metrics
        const metrics: AICallMetrics = {
          useCase: opts.useCase,
          requestId: opts.requestId,
          model: response.model,
          tier: effectiveRequest.tier,
          inputTokens: response.usage.inputTokens,
          outputTokens: response.usage.outputTokens,
          estimatedCostUsd: estimateCost(
            effectiveRequest.tier,
            response.usage.inputTokens,
            response.usage.outputTokens
          ),
          latencyMs,
          cached: false,
          success: true,
          timestamp: new Date().toISOString(),
        };
        recordMetrics(metrics);

        return response;
      } catch (err) {
        const latencyMs = Date.now() - startTime;
        const errorMessage = err instanceof Error ? err.message : "Unknown error";

        // Only count transient errors against the circuit breaker
        const isTransient = err instanceof AIProviderError && err.kind === "transient";
        if (isTransient) {
          circuitBreaker.recordFailure();
        }

        recordFailureMetrics(effectiveRequest, opts, latencyMs, errorMessage);
        throw err;
      }
    },

    async *stream(
      request: AIRequest,
      opts: OrchestratorOptions,
      streamOptions?: AIStreamOptions
    ): AsyncIterable<AIStreamChunk> {
      const effectiveRequest = opts.tierOverride
        ? { ...request, tier: opts.tierOverride }
        : request;

      // Circuit breaker check
      if (!circuitBreaker.canExecute()) {
        const error = new AIProviderError(
          "Circuit breaker is open — AI provider is unavailable",
          "transient"
        );
        recordFailureMetrics(effectiveRequest, opts, 0, error.message);
        throw error;
      }

      const startTime = Date.now();
      let firstChunkTime: number | null = null;
      let totalText = "";

      // Fallback: if provider doesn't support streaming, use complete()
      if (!provider.stream) {
        logger.info("Provider does not support streaming, falling back to complete()", {
          provider: provider.name,
          useCase: opts.useCase,
        });

        const response = await provider.complete(effectiveRequest);
        const latencyMs = Date.now() - startTime;
        const text = response.content
          .filter((b) => b.type === "text")
          .map((b) => (b as { type: "text"; text: string }).text)
          .join("");

        circuitBreaker.recordSuccess();

        const metrics: AICallMetrics = {
          useCase: opts.useCase,
          requestId: opts.requestId,
          model: response.model,
          tier: effectiveRequest.tier,
          inputTokens: response.usage.inputTokens,
          outputTokens: response.usage.outputTokens,
          estimatedCostUsd: estimateCost(
            effectiveRequest.tier,
            response.usage.inputTokens,
            response.usage.outputTokens
          ),
          latencyMs,
          cached: false,
          success: true,
          timestamp: new Date().toISOString(),
          timeToFirstTokenMs: latencyMs,
        };
        recordMetrics(metrics);

        yield {
          text,
          done: true,
          usage: {
            inputTokens: response.usage.inputTokens,
            outputTokens: response.usage.outputTokens,
            cost: estimateCost(
              effectiveRequest.tier,
              response.usage.inputTokens,
              response.usage.outputTokens
            ),
          },
        };
        return;
      }

      try {
        for await (const chunk of provider.stream(effectiveRequest, streamOptions)) {
          // Track time-to-first-token
          if (firstChunkTime === null && chunk.text) {
            firstChunkTime = Date.now();
            const ttft = firstChunkTime - startTime;

            if (ttft > 2000) {
              logger.warn("Time-to-first-token exceeds 2s SLA", {
                ttftMs: ttft,
                useCase: opts.useCase,
                provider: provider.name,
              });
            }
          }

          totalText += chunk.text;

          // On final chunk, record metrics
          if (chunk.done) {
            const latencyMs = Date.now() - startTime;
            circuitBreaker.recordSuccess();

            const metrics: AICallMetrics = {
              useCase: opts.useCase,
              requestId: opts.requestId,
              model: `${provider.name}-stream`,
              tier: effectiveRequest.tier,
              inputTokens: chunk.usage?.inputTokens ?? 0,
              outputTokens: chunk.usage?.outputTokens ?? 0,
              estimatedCostUsd: chunk.usage?.cost ?? 0,
              latencyMs,
              cached: false,
              success: true,
              timestamp: new Date().toISOString(),
              timeToFirstTokenMs: firstChunkTime ? firstChunkTime - startTime : undefined,
            };
            recordMetrics(metrics);
          }

          yield chunk;
        }
      } catch (err) {
        const latencyMs = Date.now() - startTime;
        const errorMessage = err instanceof Error ? err.message : "Unknown error";

        const isTransient = err instanceof AIProviderError && err.kind === "transient";
        if (isTransient) {
          circuitBreaker.recordFailure();
        }

        recordFailureMetrics(effectiveRequest, opts, latencyMs, errorMessage);

        // Fallback: if streaming failed mid-way, try complete()
        if (totalText === "") {
          logger.info("Streaming failed, falling back to complete()", {
            useCase: opts.useCase,
            error: errorMessage,
          });

          try {
            const response = await provider.complete(effectiveRequest);
            const fallbackLatency = Date.now() - startTime;
            circuitBreaker.recordSuccess();

            const text = response.content
              .filter((b) => b.type === "text")
              .map((b) => (b as { type: "text"; text: string }).text)
              .join("");

            const metrics: AICallMetrics = {
              useCase: `${opts.useCase}-stream-fallback`,
              requestId: opts.requestId,
              model: response.model,
              tier: effectiveRequest.tier,
              inputTokens: response.usage.inputTokens,
              outputTokens: response.usage.outputTokens,
              estimatedCostUsd: estimateCost(
                effectiveRequest.tier,
                response.usage.inputTokens,
                response.usage.outputTokens
              ),
              latencyMs: fallbackLatency,
              cached: false,
              success: true,
              timestamp: new Date().toISOString(),
            };
            recordMetrics(metrics);

            yield {
              text,
              done: true,
              usage: {
                inputTokens: response.usage.inputTokens,
                outputTokens: response.usage.outputTokens,
                cost: estimateCost(
                  effectiveRequest.tier,
                  response.usage.inputTokens,
                  response.usage.outputTokens
                ),
              },
            };
            return;
          } catch (fallbackErr) {
            // Both stream and complete failed
            throw fallbackErr;
          }
        }

        throw err;
      }
    },

    getCircuitState(): CircuitState {
      return circuitBreaker.getState();
    },

    resetCircuit(): void {
      circuitBreaker.reset();
    },
  };
}

function recordFailureMetrics(
  request: AIRequest,
  opts: OrchestratorOptions,
  latencyMs: number,
  error: string
): void {
  const metrics: AICallMetrics = {
    useCase: opts.useCase,
    requestId: opts.requestId,
    model: "unknown",
    tier: request.tier,
    inputTokens: 0,
    outputTokens: 0,
    estimatedCostUsd: 0,
    latencyMs,
    cached: false,
    success: false,
    error,
    timestamp: new Date().toISOString(),
  };
  recordMetrics(metrics);
}

// ---------------------------------------------------------------------------
// Singleton — shared orchestrator instance for the application
// ---------------------------------------------------------------------------

/** ADR-032: anchored on globalThis — a module-scope `let` is duplicated per bundle entry. */
const ORCHESTRATOR_KEY = "platform.ai.orchestrator";
function readDefaultOrchestrator(): Orchestrator | null {
  return getSingleton<Orchestrator | null>(ORCHESTRATOR_KEY, () => null);
}
function writeDefaultOrchestrator(next: Orchestrator | null): void {
  setSingleton<Orchestrator | null>(ORCHESTRATOR_KEY, next);
}

/** Get the shared orchestrator instance — lazily created */
export function getOrchestrator(): Orchestrator {
  // Read once into a local: narrowing flows through a binding, not through a call, so
  // `return readDefaultOrchestrator()` would still be `Orchestrator | null`. This also
  // avoids a second registry lookup per call.
  const existing = readDefaultOrchestrator();
  if (existing) return existing;
  const created = createOrchestrator();
  writeDefaultOrchestrator(created);
  return created;
}

/**
 * Replace the default orchestrator — used in tests to inject mocks.
 * Returns the previous orchestrator for cleanup.
 */
export function setOrchestrator(orchestrator: Orchestrator): Orchestrator | null {
  const previous = readDefaultOrchestrator();
  writeDefaultOrchestrator(orchestrator);
  return previous;
}
