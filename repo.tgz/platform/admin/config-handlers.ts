/**
 * platform/admin/config-handlers.ts — Config agent tool implementations
 *
 * Each function implements one tool that the config management agent can
 * invoke. Tools are stateless — they read/write via platform-config and
 * the approval/impact services. The agent orchestrates tool calls; these
 * functions just do the work.
 *
 * Tool roster (10):
 *   search_config      — find config entries by keyword, category, tier
 *   get_config         — get a single config entry with full metadata
 *   update_config      — validated update with reconfirmation data
 *   get_history        — change history for a key or all keys
 *   compare_to_defaults — show current vs default values
 *   impact_report      — moderation outcome changes after a config change
 *   bulk_review        — review all entries in a category or tier
 *   request_approval   — create a pending approval for safety-critical changes
 *   approve_change     — approve a pending change (different super_admin)
 *   reject_change      — reject a pending change
 *
 * GenAI Principles:
 *   P2  — Agentic execution: tools are bounded, single-purpose operations
 *   P3  — Total observability: every tool call timed; trajectory recorded at dispatch level
 *   P5  — Versioned artifacts: tool definitions exported for agent registration
 *   P6  — Structured outputs: all results typed via ConfigToolResult
 *   P10 — Human oversight: update_config requires confirmed:true to apply (preview by default)
 *   P13 — Control plane: permission tier checks on every mutation
 *   P15 — Agent identity: agentId threaded through trajectory context
 *   P17 — Cognition-commitment: read tools = cognition, write tools = commitment
 *   P18 — Durable trajectories: steps recorded per tool call via ToolExecutionContext
 *
 * @module platform/admin
 */

import {
  getEnhancedConfig,
  listEnhancedConfig,
  validateConfigValue,
  setConfigWithHistory,
  getConfigHistory,
  getConfig,
} from "@/platform/auth/platform-config";
import {
  isApprovalRequired,
  requestApproval as createApprovalRequest,
  approveChange as approveApprovalChange,
  rejectChange as rejectApprovalChange,
} from "./config-approval";
import { generateImpactReport, isModerationConfig } from "./config-impact";
import type {
  ConfigToolResult,
  ConfigChangeRequest,
  ConfigSearchOptions,
  ConfigHistoryOptions,
  PermissionTier,
  EnhancedConfigEntry,
  ToolExecutionContext,
} from "./types";
import { TOOL_BOUNDARIES } from "./types";
import type { Tool, StepBoundary, AgentIdentity } from "@/platform/agents/types";
import { invokeTool } from "@/platform/agents/tool-invoker";
import { getTrajectoryStore } from "@/platform/agents/trajectory-store";
import { getProposalStore } from "@/platform/agents/proposal-store";
import { proposeOnce, PipelineRejectedError } from "@/platform/action-pipeline";
import { approvalPolicy } from "@/platform/agents/gating";
import { getApprovalPolicyStore } from "@/platform/agents/approval-policy-store";
import { logger } from "@/lib/logger";

// ---------------------------------------------------------------------------
// Tool execution wrapper
// ---------------------------------------------------------------------------

/**
 * Wrap a tool handler in timing and error handling.
 * Every tool call produces a ConfigToolResult regardless of outcome.
 */
async function executeToolCall<T>(
  toolId: string,
  fn: () => Promise<T>
): Promise<ConfigToolResult> {
  const start = Date.now();
  try {
    const data = await fn();
    return {
      toolId,
      success: true,
      data,
      durationMs: Date.now() - start,
    };
  } catch (err) {
    return {
      toolId,
      success: false,
      data: null,
      error: err instanceof Error ? err.message : String(err),
      durationMs: Date.now() - start,
    };
  }
}

// ---------------------------------------------------------------------------
// Tool: search_config
// ---------------------------------------------------------------------------

export interface SearchConfigInput {
  readonly query?: string;
  readonly category?: string;
  readonly permissionTier?: PermissionTier;
}

/**
 * Search config entries by keyword, category, or permission tier.
 * Returns matching entries with full metadata.
 */
export async function handleSearchConfig(
  input: SearchConfigInput
): Promise<ConfigToolResult> {
  return executeToolCall("search_config", async () => {
    const options: ConfigSearchOptions = {
      query: input.query,
      category: input.category,
      permissionTier: input.permissionTier,
    };
    const entries = await listEnhancedConfig(options);
    return {
      entries,
      count: entries.length,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool: get_config
// ---------------------------------------------------------------------------

export interface GetConfigInput {
  readonly key: string;
}

/**
 * Get a single config entry with full metadata.
 */
export async function handleGetConfig(input: GetConfigInput): Promise<ConfigToolResult> {
  return executeToolCall("get_config", async () => {
    const entry = await getEnhancedConfig(input.key);
    if (!entry) {
      return { found: false, key: input.key };
    }
    return { found: true, entry };
  });
}

// ---------------------------------------------------------------------------
// Tool: update_config
// ---------------------------------------------------------------------------

export interface UpdateConfigInput {
  readonly key: string;
  readonly value: unknown;
  readonly changeComment: string;
  readonly actorId: string;
  /**
   * P10: Must be true to apply the change. When false or absent,
   * returns a preview (changeRequest) without applying. The agent
   * presents the preview, admin confirms, agent calls again with
   * confirmed: true.
   */
  readonly confirmed?: boolean;
}

/**
 * Update a config entry with full validation.
 *
 * This tool does NOT auto-apply the change. It returns a
 * ConfigChangeRequest with all reconfirmation data. The agent
 * presents this to the admin for confirmation. Only after
 * explicit confirmation does the agent call update_config with confirmed: true.
 *
 * For safety-tier keys with two-person approval enabled, this
 * creates a pending approval instead of applying.
 */
export async function handleUpdateConfig(
  input: UpdateConfigInput
): Promise<ConfigToolResult> {
  return executeToolCall("update_config", async () => {
    // 1. Load entry metadata
    const entry = await getEnhancedConfig(input.key);
    if (!entry) {
      return {
        applied: false,
        error: `Config key "${input.key}" not found.`,
      };
    }

    // 2. Validate proposed value
    const validation = validateConfigValue(entry, input.value);
    if (!validation.valid) {
      return {
        applied: false,
        validationErrors: validation.errors,
      };
    }

    // 3. Check if two-person approval is needed
    const needsApproval =
      entry.permissionTier === "safety" && (await isApprovalRequired());

    // 4. Build the reconfirmation data (A8: pure function, independently testable)
    const changeRequest = buildChangeRequest(
      entry,
      input.value,
      input.changeComment,
      needsApproval
    );

    // P10: If not explicitly confirmed, return preview only
    if (!input.confirmed) {
      return {
        applied: false,
        pendingConfirmation: true,
        changeRequest,
      };
    }

    if (needsApproval) {
      // Create pending approval — don't apply
      const approvalResult = await createApprovalRequest({
        configKey: input.key,
        currentValue: entry.value,
        proposedValue: input.value,
        requestedBy: input.actorId,
        changeComment: input.changeComment,
        impactSummary: changeRequest.impact,
      });

      return {
        applied: false,
        requiresApproval: true,
        approval: approvalResult.record,
        approvalError: approvalResult.error,
        changeRequest,
      };
    }

    // 5. Apply the change directly (A5: pass loaded entry to skip re-load)
    const result = await setConfigWithHistory(
      input.key,
      input.value,
      input.actorId,
      input.changeComment,
      "config_agent",
      entry
    );

    return {
      applied: result.success,
      error: result.error,
      validationErrors: result.validationErrors,
      changeRequest,
    };
  });
}

/**
 * Build a ConfigChangeRequest from an entry and proposed value.
 * Pure function — no side effects, independently testable.
 * Extracted per A8/B8 sustainability review.
 */
export function buildChangeRequest(
  entry: EnhancedConfigEntry,
  proposedValue: unknown,
  changeComment: string,
  requiresApproval: boolean
): ConfigChangeRequest {
  return {
    key: entry.key,
    currentValue: entry.value,
    proposedValue,
    impact: buildImpactDescription(entry, proposedValue),
    affectedUsers: buildAffectedUsersDescription(entry),
    reversible: true,
    permissionTier: entry.permissionTier,
    requiresApproval,
    changeComment,
  };
}

/** Generate a human-readable impact description */
function buildImpactDescription(
  entry: EnhancedConfigEntry,
  proposedValue: unknown
): string {
  const parts: string[] = [];

  parts.push(
    `Changing "${entry.key}" from ${JSON.stringify(entry.value)} to ${JSON.stringify(proposedValue)}.`
  );

  if (entry.permissionTier === "safety") {
    parts.push(
      "This is a safety-critical setting. Changes affect content moderation behavior."
    );
  }

  if (entry.key.includes("block_severity") || entry.key.includes("warn_severity")) {
    parts.push(
      "Moderation threshold changes affect how content is screened in real-time."
    );
  }

  if (entry.key.includes("strike")) {
    parts.push("Strike threshold changes affect account consequence escalation.");
  }

  if (entry.key === "maintenance_mode") {
    parts.push("Enabling maintenance mode makes the platform read-only for all users.");
  }

  if (entry.key === "signups_enabled") {
    parts.push("Disabling signups prevents new account creation.");
  }

  return parts.join(" ");
}

/** Generate a human-readable description of affected users */
function buildAffectedUsersDescription(entry: EnhancedConfigEntry): string {
  if (entry.key.includes("level1")) {
    return "Users under 13 (COPPA-protected, strictest content rating)";
  }
  if (entry.key.includes("level2")) {
    return "Teen users (13–17, moderate content rating)";
  }
  if (entry.key.includes("level3")) {
    return "Adult users (18+, standard content rating)";
  }
  if (entry.key.includes("strike")) {
    return "All users — affects account consequence escalation";
  }
  if (entry.key === "rate_limit_rpm") {
    return "All users — affects API request throttling";
  }
  if (entry.key === "maintenance_mode" || entry.key === "signups_enabled") {
    return "All users — platform-wide setting";
  }
  if (entry.category === "moderation") {
    return "All users — affects content safety pipeline";
  }
  return "Varies by setting";
}

// ---------------------------------------------------------------------------
// Tool: get_history
// ---------------------------------------------------------------------------

export interface GetHistoryInput {
  readonly configKey?: string;
  readonly limit?: number;
  readonly since?: string;
  readonly before?: string;
}

/**
 * Get change history for a config key or all keys.
 */
export async function handleGetHistory(
  input: GetHistoryInput
): Promise<ConfigToolResult> {
  return executeToolCall("get_history", async () => {
    const options: ConfigHistoryOptions = {
      configKey: input.configKey,
      limit: input.limit ?? 20,
      since: input.since,
      before: input.before,
    };
    const records = await getConfigHistory(options);
    return {
      records,
      count: records.length,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool: compare_to_defaults
// ---------------------------------------------------------------------------

export interface CompareToDefaultsInput {
  readonly category?: string;
  readonly onlyDrifted?: boolean;
}

/**
 * Compare current config values to their defaults.
 * Optionally filtered to only show values that have drifted.
 */
export async function handleCompareToDefaults(
  input: CompareToDefaultsInput
): Promise<ConfigToolResult> {
  return executeToolCall("compare_to_defaults", async () => {
    const entries = await listEnhancedConfig({
      category: input.category,
    });

    const comparisons = entries.map((entry) => ({
      key: entry.key,
      currentValue: entry.value,
      defaultValue: entry.defaultValue,
      isDrifted: JSON.stringify(entry.value) !== JSON.stringify(entry.defaultValue),
      category: entry.category,
      permissionTier: entry.permissionTier,
    }));

    const filtered = input.onlyDrifted
      ? comparisons.filter((c) => c.isDrifted)
      : comparisons;

    return {
      comparisons: filtered,
      totalCount: comparisons.length,
      driftedCount: comparisons.filter((c) => c.isDrifted).length,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool: impact_report
// ---------------------------------------------------------------------------

export interface ImpactReportInput {
  readonly configKey: string;
  readonly limit?: number;
}

/**
 * Generate impact reports for recent changes to a config key.
 * Only meaningful for moderation-category config keys.
 */
export async function handleImpactReport(
  input: ImpactReportInput
): Promise<ConfigToolResult> {
  return executeToolCall("impact_report", async () => {
    if (!isModerationConfig(input.configKey)) {
      return {
        reports: [],
        message: `Impact reports are only available for moderation config keys. "${input.configKey}" is not a moderation key.`,
      };
    }

    const history = await getConfigHistory({
      configKey: input.configKey,
      limit: input.limit ?? 5,
    });

    if (history.length === 0) {
      return {
        reports: [],
        message: `No change history found for "${input.configKey}".`,
      };
    }

    // A11: Generate impact reports in parallel (each does 2 DB queries)
    const reportPromises = history.map((change, i) => {
      const nextChangeAt = i > 0 ? history[i - 1].createdAt : undefined;
      return generateImpactReport(change, nextChangeAt);
    });
    const reports = await Promise.all(reportPromises);

    return { reports };
  });
}

// ---------------------------------------------------------------------------
// Tool: bulk_review
// ---------------------------------------------------------------------------

export interface BulkReviewInput {
  readonly category?: string;
  readonly permissionTier?: PermissionTier;
}

/**
 * Review all config entries in a category or permission tier.
 * Groups entries by category and shows current values, defaults,
 * and drift status.
 */
export async function handleBulkReview(
  input: BulkReviewInput
): Promise<ConfigToolResult> {
  return executeToolCall("bulk_review", async () => {
    const entries = await listEnhancedConfig({
      category: input.category,
      permissionTier: input.permissionTier,
    });

    // Group by category
    const grouped: Record<string, EnhancedConfigEntry[]> = {};
    for (const entry of entries) {
      const cat = entry.category;
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(entry);
    }

    return {
      entries,
      totalCount: entries.length,
      categories: Object.keys(grouped),
      byCategory: grouped,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool: request_approval
// ---------------------------------------------------------------------------

export interface RequestApprovalInput {
  readonly configKey: string;
  readonly proposedValue: unknown;
  readonly changeComment: string;
  readonly actorId: string;
}

/**
 * Create a pending approval for a safety-critical config change.
 */
export async function handleRequestApproval(
  input: RequestApprovalInput
): Promise<ConfigToolResult> {
  return executeToolCall("request_approval", async () => {
    // Load current value
    const entry = await getEnhancedConfig(input.configKey);
    if (!entry) {
      return { success: false, error: `Config key "${input.configKey}" not found.` };
    }

    // Validate before creating approval
    const validation = validateConfigValue(entry, input.proposedValue);
    if (!validation.valid) {
      return {
        success: false,
        validationErrors: validation.errors,
      };
    }

    const result = await createApprovalRequest({
      configKey: input.configKey,
      currentValue: entry.value,
      proposedValue: input.proposedValue,
      requestedBy: input.actorId,
      changeComment: input.changeComment,
      impactSummary: buildImpactDescription(entry, input.proposedValue),
    });

    return result;
  });
}

// ---------------------------------------------------------------------------
// Tool: approve_change
// ---------------------------------------------------------------------------

export interface ApproveChangeInput {
  readonly approvalId: string;
  readonly reviewerId: string;
  readonly reviewComment: string;
}

/**
 * Approve a pending config change. Applies the change if approval succeeds.
 */
export async function handleApproveChange(
  input: ApproveChangeInput
): Promise<ConfigToolResult> {
  return executeToolCall("approve_change", async () => {
    const result = await approveApprovalChange(
      input.approvalId,
      input.reviewerId,
      input.reviewComment
    );

    if (!result.success) {
      return result;
    }

    // Gotcha #4 from config-approval: approval doesn't apply the change.
    // Apply it now that approval is granted.
    const record = result.record!;
    const applyResult = await setConfigWithHistory(
      record.configKey,
      record.proposedValue,
      input.reviewerId,
      `Approved: ${record.changeComment}`,
      "config_agent"
    );

    return {
      approved: true,
      applied: applyResult.success,
      applyError: applyResult.error,
      approval: record,
    };
  });
}

// ---------------------------------------------------------------------------
// Tool: reject_change
// ---------------------------------------------------------------------------

export interface RejectChangeInput {
  readonly approvalId: string;
  readonly reviewerId: string;
  readonly reviewComment: string;
}

/**
 * Reject a pending config change.
 */
export async function handleRejectChange(
  input: RejectChangeInput
): Promise<ConfigToolResult> {
  return executeToolCall("reject_change", async () => {
    const result = await rejectApprovalChange(
      input.approvalId,
      input.reviewerId,
      input.reviewComment
    );
    return result;
  });
}

// ---------------------------------------------------------------------------
// Tool definitions (P5) — for agent registration
// ---------------------------------------------------------------------------

/**
 * Typed tool definitions for the config management agent.
 * These are passed to the agent runtime so it knows what tools
 * are available and their input/output schemas.
 */
export const CONFIG_TOOLS: readonly Tool[] = [
  {
    id: "search_config",
    name: "Search Configuration",
    description:
      "Search config entries by keyword, category, or permission tier. Returns matching entries with full metadata including value type, constraints, and permission tier.",
    inputSchema: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "Search term — matches key or description",
        },
        category: {
          type: "string",
          description: "Filter by category (e.g., moderation, system, i18n)",
        },
        permissionTier: {
          type: "string",
          enum: ["standard", "safety"],
          description: "Filter by permission tier",
        },
      },
    },
    outputSchema: {
      type: "object",
      properties: {
        entries: { type: "array" },
        count: { type: "number" },
      },
    },
    effects: [],
    execute: async (input: Record<string, unknown>) =>
      (await handleSearchConfig(
        input as unknown as SearchConfigInput
      )) as unknown as Record<string, unknown>,
  },
  {
    id: "get_config",
    name: "Get Configuration Entry",
    description:
      "Get a single config entry by key with full metadata: current value, default value, value type, constraints, permission tier, and description.",
    inputSchema: {
      type: "object",
      properties: {
        key: { type: "string", description: "The config key to retrieve" },
      },
      required: ["key"],
    },
    outputSchema: {
      type: "object",
      properties: {
        found: { type: "boolean" },
        entry: { type: "object" },
      },
    },
    effects: [],
    execute: async (input: Record<string, unknown>) =>
      (await handleGetConfig(input as unknown as GetConfigInput)) as unknown as Record<
        string,
        unknown
      >,
  },
  {
    id: "update_config",
    name: "Update Configuration",
    description:
      "Update a config entry. Validates the value against type constraints. For safety-critical keys with two-person approval enabled, creates a pending approval. Returns reconfirmation data showing impact and affected users.",
    inputSchema: {
      type: "object",
      properties: {
        key: { type: "string", description: "Config key to update" },
        value: { description: "New value (must match the entry's value_type)" },
        changeComment: {
          type: "string",
          description: "Mandatory comment explaining why the change is being made",
        },
        actorId: { type: "string", description: "ID of the admin making the change" },
      },
      required: ["key", "value", "changeComment"],
    },
    outputSchema: {
      type: "object",
      properties: {
        applied: { type: "boolean" },
        changeRequest: { type: "object" },
        requiresApproval: { type: "boolean" },
      },
    },
    effects: ["stateWrite"],
    declaredRisk: "consequential",
    execute: async (input: Record<string, unknown>) =>
      (await handleUpdateConfig(
        input as unknown as UpdateConfigInput
      )) as unknown as Record<string, unknown>,
  },
  {
    id: "get_history",
    name: "Get Change History",
    description:
      "Get the change history for a specific config key or all keys. Shows who changed what, when, and why.",
    inputSchema: {
      type: "object",
      properties: {
        configKey: {
          type: "string",
          description: "Specific key to get history for (omit for all)",
        },
        limit: { type: "number", description: "Max records to return (default 20)" },
        since: {
          type: "string",
          description: "ISO timestamp — only changes after this time",
        },
        before: {
          type: "string",
          description: "ISO timestamp — only changes before this time",
        },
      },
    },
    outputSchema: {
      type: "object",
      properties: {
        records: { type: "array" },
        count: { type: "number" },
      },
    },
    effects: [],
    execute: async (input: Record<string, unknown>) =>
      (await handleGetHistory(input as unknown as GetHistoryInput)) as unknown as Record<
        string,
        unknown
      >,
  },
  {
    id: "compare_to_defaults",
    name: "Compare to Defaults",
    description:
      "Compare current config values to their seed defaults. Identifies settings that have drifted from defaults. Useful for auditing and troubleshooting.",
    inputSchema: {
      type: "object",
      properties: {
        category: { type: "string", description: "Filter by category" },
        onlyDrifted: {
          type: "boolean",
          description: "Only show values that differ from defaults",
        },
      },
    },
    outputSchema: {
      type: "object",
      properties: {
        comparisons: { type: "array" },
        totalCount: { type: "number" },
        driftedCount: { type: "number" },
      },
    },
    effects: [],
    execute: async (input: Record<string, unknown>) =>
      (await handleCompareToDefaults(
        input as unknown as CompareToDefaultsInput
      )) as unknown as Record<string, unknown>,
  },
  {
    id: "impact_report",
    name: "Impact Report",
    description:
      "Show how moderation outcomes changed after a config change. Compares block/warn rates before and after. Only works for moderation-category config keys.",
    inputSchema: {
      type: "object",
      properties: {
        configKey: { type: "string", description: "Moderation config key to analyze" },
        limit: {
          type: "number",
          description: "Number of recent changes to analyze (default 5)",
        },
      },
      required: ["configKey"],
    },
    outputSchema: {
      type: "object",
      properties: {
        reports: { type: "array" },
        message: { type: "string" },
      },
    },
    effects: [],
    execute: async (input: Record<string, unknown>) =>
      (await handleImpactReport(
        input as unknown as ImpactReportInput
      )) as unknown as Record<string, unknown>,
  },
  {
    id: "bulk_review",
    name: "Bulk Review",
    description:
      "Review all config entries in a category or permission tier. Groups entries by category for organized review.",
    inputSchema: {
      type: "object",
      properties: {
        category: { type: "string", description: "Filter by category" },
        permissionTier: {
          type: "string",
          enum: ["standard", "safety"],
          description: "Filter by permission tier",
        },
      },
    },
    outputSchema: {
      type: "object",
      properties: {
        entries: { type: "array" },
        totalCount: { type: "number" },
        categories: { type: "array" },
      },
    },
    effects: [],
    execute: async (input: Record<string, unknown>) =>
      (await handleBulkReview(input as unknown as BulkReviewInput)) as unknown as Record<
        string,
        unknown
      >,
  },
  {
    id: "request_approval",
    name: "Request Approval",
    description:
      "Create a pending approval for a safety-critical config change. Another super_admin must approve before the change takes effect.",
    inputSchema: {
      type: "object",
      properties: {
        configKey: { type: "string", description: "Config key to change" },
        proposedValue: { description: "Proposed new value" },
        changeComment: { type: "string", description: "Why this change is needed" },
        actorId: { type: "string", description: "ID of the requesting admin" },
      },
      required: ["configKey", "proposedValue", "changeComment"],
    },
    outputSchema: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        record: { type: "object" },
      },
    },
    effects: ["stateWrite"],
    declaredRisk: "consequential",
    execute: async (input: Record<string, unknown>) =>
      (await handleRequestApproval(
        input as unknown as RequestApprovalInput
      )) as unknown as Record<string, unknown>,
  },
  {
    id: "approve_change",
    name: "Approve Change",
    description:
      "Approve a pending config change. The reviewer must be a different super_admin than the requester. On approval, the change is applied immediately.",
    inputSchema: {
      type: "object",
      properties: {
        approvalId: { type: "string", description: "ID of the pending approval" },
        reviewerId: { type: "string", description: "ID of the reviewing admin" },
        reviewComment: { type: "string", description: "Review comment" },
      },
      required: ["approvalId", "reviewComment"],
    },
    outputSchema: {
      type: "object",
      properties: {
        approved: { type: "boolean" },
        applied: { type: "boolean" },
      },
    },
    effects: ["stateWrite"],
    declaredRisk: "consequential",
    execute: async (input: Record<string, unknown>) =>
      (await handleApproveChange(
        input as unknown as ApproveChangeInput
      )) as unknown as Record<string, unknown>,
  },
  {
    id: "reject_change",
    name: "Reject Change",
    description:
      "Reject a pending config change. The requester can also reject their own request (to cancel it).",
    inputSchema: {
      type: "object",
      properties: {
        approvalId: { type: "string", description: "ID of the pending approval" },
        reviewerId: { type: "string", description: "ID of the reviewing admin" },
        reviewComment: { type: "string", description: "Reason for rejection" },
      },
      required: ["approvalId", "reviewComment"],
    },
    outputSchema: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        record: { type: "object" },
      },
    },
    effects: ["stateWrite"],
    declaredRisk: "consequential",
    execute: async (input: Record<string, unknown>) =>
      (await handleRejectChange(
        input as unknown as RejectChangeInput
      )) as unknown as Record<string, unknown>,
  },
] as const;

// ---------------------------------------------------------------------------
// Tool dispatcher — maps tool ID to handler
// ---------------------------------------------------------------------------

/** Required fields per tool (B5: validate before dispatch, not accidentally) */
const REQUIRED_FIELDS: Record<string, readonly string[]> = {
  get_config: ["key"],
  update_config: ["key", "value", "changeComment"],
  impact_report: ["configKey"],
  request_approval: ["configKey", "proposedValue", "changeComment"],
  approve_change: ["approvalId", "reviewComment"],
  reject_change: ["approvalId", "reviewComment"],
};

/**
 * Dispatch a tool call by ID with trajectory recording.
 *
 * Architecture:
 *   - B5: Validates required fields before dispatching (intentional, not accidental)
 *   - P17: Classifies each tool as cognition (read) or commitment (write)
 *   - P18: Records a step in the trajectory context after execution
 *   - Input casting: Record<string, unknown> → typed input. Type safety is at
 *     tool schema level (P6) + handler validation (validateConfigValue).
 *     See Gotcha #3.
 */
/** Roster lookup — CONFIG_TOOLS is the single source of truth for what is dispatchable. */
const CONFIG_TOOL_BY_ID: ReadonlyMap<string, Tool> = new Map(
  CONFIG_TOOLS.map((tool) => [tool.id, tool])
);

export async function dispatchConfigTool(
  toolId: string,
  input: Record<string, unknown>,
  context?: ToolExecutionContext
): Promise<ConfigToolResult> {
  // B5: Validate required fields before dispatching
  const requiredFields = REQUIRED_FIELDS[toolId];
  if (requiredFields) {
    const missing = requiredFields.filter(
      (f) => input[f] === undefined || input[f] === null
    );
    if (missing.length > 0) {
      return {
        toolId,
        success: false,
        data: null,
        error: `Missing required fields: ${missing.join(", ")}`,
        durationMs: 0,
      };
    }
  }

  // ADR-029 D1: the roster is the dispatcher. A tool is invocable because it carries its
  // handler, not because a switch elsewhere happens to name it — the switch and the roster
  // could previously disagree, and nothing would have said so.
  const tool = CONFIG_TOOL_BY_ID.get(toolId);
  if (!tool) {
    return {
      toolId,
      success: false,
      data: null,
      error: `Unknown tool: ${toolId}`,
      durationMs: 0,
    };
  }

  // ADR-039 F2b: run through the governed runtime (invokeTool) — risk floor, budget ceiling,
  // effect ledger and trajectory recording — rather than a hand-rolled step. A config write's
  // effectiveRisk (stateWrite floor = ordinary, declaredRisk = consequential) stays below the
  // gating threshold (restricted), so nothing holds here; dual-control (F2b-2) raises risk on
  // named keys to cross it. config-approval remains the domain two-person gate.
  const trajectoryStore = getTrajectoryStore();
  const actor: AgentIdentity = {
    actorType: "agent",
    actorId: context?.agentId ?? "config-manager",
    agentRole: "config-manager",
  };
  const existingTrajectoryId = context?.trajectoryId;
  let trajectoryId: string;
  if (existingTrajectoryId && (await trajectoryStore.getById(existingTrajectoryId))) {
    trajectoryId = existingTrajectoryId;
  } else {
    const created = await trajectoryStore.create(
      { kind: "agent", id: actor.actorId },
      `config:${toolId}`,
      "platform"
    );
    trajectoryId = created.trajectory.trajectoryId;
  }

  // ADR-039 F2b-2 dual-control: a config write to a key in config.dual_control_keys is
  // catastrophic-if-wrong, so raise its risk to `restricted` — crossing the gating threshold
  // forces a runtime hold cleared by an independent human (approval policy default = "user"),
  // on top of config-approval's domain two-person gate. Non-listed keys stay below the line.
  const dualControlKeys = await getConfig<string[]>("config.dual_control_keys", []);
  const targetKey = typeof input.key === "string" ? input.key : undefined;
  const isDualControl =
    toolId === "update_config" &&
    targetKey !== undefined &&
    dualControlKeys.includes(targetKey);
  const effectiveTool: Tool = isDualControl
    ? { ...tool, declaredRisk: "restricted" }
    : tool;

  let result: ConfigToolResult;
  try {
    const invoked = await invokeTool({
      tool: effectiveTool,
      input,
      actor,
      sessionId: trajectoryId,
      trajectoryId,
      stepIndex: context?.steps.length ?? 0,
      trajectoryStore,
      proposalStore: getProposalStore(),
    });
    result = invoked.output as unknown as ConfigToolResult;
  } catch (err) {
    // A dual-control write holds rather than fails: mint the proposal (idempotent) and surface
    // who must approve. This is not an error — the change is pending an independent human, not
    // broken. Clearing the hold (re-invoke with the approved proposal) is the ADR-040 surface.
    if (err instanceof PipelineRejectedError && err.reason === "requires-approval") {
      const stepIndex = context?.steps.length ?? 0;
      const proposal = await proposeOnce({
        spec: {
          type: effectiveTool.id,
          effects: effectiveTool.effects,
          declaredRisk: effectiveTool.declaredRisk,
          ephemeral: false,
          commutative: false,
        },
        actor,
        sessionId: trajectoryId,
        operationId: `op_${trajectoryId}_${stepIndex}`,
        label: effectiveTool.id,
        payload: input,
        trajectoryId,
        stepIndex,
        proposalStore: getProposalStore(),
        trajectoryStore,
      });
      const policy = await getApprovalPolicyStore().load();
      const approver = approvalPolicy(
        proposal.effectiveRisk,
        effectiveTool.effects,
        policy
      );
      return {
        toolId,
        success: false,
        held: true,
        data: {
          pendingApproval: true,
          proposalId: proposal.proposalId,
          operationId: proposal.operationId,
          requiredApprover: approver.actorType,
        },
        approval: {
          proposalId: proposal.proposalId,
          operationId: proposal.operationId,
          requiredApprover: approver.actorType,
        },
        durationMs: 0,
      };
    }
    logger.error("Config tool invocation failed in the runtime pipeline", {
      route: "platform/admin/config-handlers",
      toolId,
      error: err instanceof Error ? err.message : String(err),
    });
    return {
      toolId,
      success: false,
      data: null,
      error: err instanceof Error ? err.message : "Tool invocation failed",
      durationMs: 0,
    };
  }

  // Project the governed step into the response view. The runtime trajectory is the source
  // of truth; context.steps is this request's response projection, keeping the per-tool
  // boundary for the UI.
  if (context && result) {
    // Fail closed. An unclassified tool gets the STRICTER boundary, not the lower one:
    // recording a state-changing tool as cognition would place it below the governance a
    // commitment receives. Not a throw — this is a recording concern, and refusing to run a
    // working tool because its boundary is unlisted is a worse failure than recording it
    // conservatively (TASK-064).
    const classified = TOOL_BOUNDARIES[toolId];
    if (!classified) {
      logger.warn("Tool has no boundary classification — recording as commitment", {
        route: "platform/admin/config-handlers",
        toolId,
      });
    }
    const boundary: StepBoundary = classified ?? "commitment";
    context.steps.push({
      stepIndex: context.steps.length,
      action: toolId,
      boundary,
      input: { toolId },
      output: { success: result.success },
      cost: 0,
      durationMs: result.durationMs,
      timestamp: new Date().toISOString(),
    });
  }

  return result;
}

// ---------------------------------------------------------------------------
// Gotchas (L17)
// ---------------------------------------------------------------------------
//
// 1. handleUpdateConfig does NOT auto-apply for safety-tier keys when
//    two-person approval is enabled. It creates a pending approval.
//    The admin must confirm separately. handleApproveChange applies the
//    change after a different admin approves.
//
// 2. handleApproveChange applies the config change using the REVIEWER's
//    actorId (not the requester's). The history record shows who approved,
//    not who requested. Both IDs are in the approval record.
//
// 3. dispatchConfigTool uses `as unknown as` for input casting. This is
//    intentional — the agent runtime passes Record<string, unknown>.
//    Type safety is enforced at three levels: (a) REQUIRED_FIELDS check
//    in dispatcher catches missing fields (B5), (b) tool schemas define
//    the contract (P6), (c) handlers validate values (validateConfigValue).
//
// 4. CONFIG_TOOLS is `as const` — immutable array. When the agent runtime
//    registers tools (Sprint 4a), it reads from this array. Do not mutate.
//
// 5. handleApproveChange: if the approval succeeds but setConfigWithHistory
//    fails, the approval record shows "approved" but the config value is
//    unchanged. This is intentional — the approval decision and the config
//    mutation are separate facts. The response includes both `approved: true`
//    and `applied: false` with `applyError`. Recovery: fix the underlying
//    issue (e.g., DB connectivity) and re-execute the apply manually.
//    A cron job to detect "approved but not applied" states is a future
//    enhancement.
//
// 6. The `Tool` import from agents/types uses JSON Schema for inputSchema
//    and outputSchema. These are descriptive (for the LLM), not enforced
//    at runtime. Runtime validation happens in each handler via
//    validateConfigValue().
