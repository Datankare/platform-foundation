# GenAI-Native Roadmap

**Owner:** Raman Sud, CTO
**Canonical location:** `docs/GENAI_ROADMAP.md`
**Governing ADRs:** ADR-003 (GenAI-Native), ADR-015 (GenAI-Native Stack), ADR-017 (Complete Surface Map)
**Rule:** Updated at every sprint boundary. No GenAI capability is built without placement here first (Standing Rule 12).

> **Consumer note:** This document describes platform-level GenAI capabilities.
> Consumer applications (e.g., games, learning tools, SaaS products) extend these
> capabilities with app-specific implementations in their own repos.

---

## The GenAI-Native Principle

GenAI is the medium the platform operates in — not a feature bolted on. Every user interaction, every admin action, every safety decision, every piece of content flows through AI infrastructure that is instrumented, cached, budgeted, monitored, resilient, and explainable.

The 18 principles that define what "GenAI-native" means for this platform are documented in the **[GenAI-Native Systems Manifesto](./GENAI_MANIFESTO.md)**. This roadmap maps those principles to phased delivery.

---

## Phase Summary

| Phase | GenAI Status | Key GenAI Capabilities                                                                                                                               |
| ----- | ------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1     | ✅ Complete  | Admin AI command bar                                                                                                                                 |
| 2     | ✅ Complete  | Orchestration, prompt registry, safety, moderation, observability, cache, rate limiting, realtime, streaming, provider registry                      |
| 3     | ✅ Complete  | Voice pipeline (P1-P18 agentic), song ID, translation/TTS/STT providers, canonical audio format                                                      |
| 4     | ✅ Complete  | RAG, embeddings, cognitive memory, explainability, Guardian/Sentinel agents, agent runtime, conformance kits                                         |
| 5     | 🔄 Sprint 4b | Application framework, agentic workflow, AUX, agent identity + governance, registry unification (ADR-028–041); adaptive behavior + multimodal remain |
| 6     | ⏳ Upcoming  | Token budgets, cost attribution, A/B testing                                                                                                         |
| 7     | ⏳ Upcoming  | AI quality monitoring, personalization, feedback loop, NL analytics                                                                                  |
| 8     | ⏳ Upcoming  | AI hardening, fallback chains, graceful degradation                                                                                                  |

---

## Phase 1 — Identity & Access Foundation ✅

| Capability           | Status       | Detail                                                                                                     |
| -------------------- | ------------ | ---------------------------------------------------------------------------------------------------------- |
| Admin AI command bar | ✅ Delivered | Natural language → structured plan → human confirm → execute. Admin operations flow through AI, not forms. |

---

## Phase 2 — Communication Foundation ✅

| Capability                      | Status       | Detail                                                                                                                                   |
| ------------------------------- | ------------ | ---------------------------------------------------------------------------------------------------------------------------------------- |
| LLM orchestration layer         | ✅ Sprint 1  | `platform/ai/orchestrator.ts` — provider abstraction, model tiering (Haiku/Sonnet), circuit breaker, retry                               |
| Provider interface              | ✅ Sprint 1  | `platform/ai/provider.ts` — Anthropic primary, pluggable fallback. No raw `fetch()` to LLM APIs.                                         |
| AI call instrumentation         | ✅ Sprint 1  | Every AI call auto-records: model, tokens in/out, latency, estimated cost, success/failure                                               |
| Prompt registry                 | ✅ Sprint 1  | `prompts/` — versioned prompts with tests, registry with version resolution                                                              |
| Admin AI refactored             | ✅ Sprint 1  | Raw `fetch()` + inline prompt → orchestrator + prompt registry                                                                           |
| Safety classifier refactored    | ✅ Sprint 1  | Anthropic SDK direct call → orchestrator. Structured output: 6 categories, confidence, severity                                          |
| Blocklist pre-screen (Layer 1)  | ✅ Sprint 2  | `platform/moderation/blocklist.ts` — instant, zero-cost pattern matching. safe-regex2 validated.                                         |
| LLM classifier (Layer 2)        | ✅ Sprint 2  | `platform/moderation/classifier.ts` — structured classification via orchestrator                                                         |
| Safety middleware               | ✅ Sprint 2  | `platform/moderation/middleware.ts` — universal pipeline for input AND output screening (ADR-017)                                        |
| Moderation audit trail          | ✅ Sprint 2  | SHA-256 hashed input, full classifier output, action, direction logged per decision                                                      |
| Guardian agent (Layer 3)        | ✅ Sprint 2  | `platform/moderation/guardian.ts` — agentic screening with trajectories, reasoning, context-aware decisions                              |
| Content rating (COPPA tiers)    | ✅ Sprint 2  | Age-based thresholds: Level 1 (under 13), Level 2 (13-17), Level 3 (18+). Config-driven, fail-closed.                                    |
| Config management agent         | ✅ Sprint 3a | `platform/admin/` — 10-tool agent with approval, impact correlation, trajectory recording                                                |
| Versioned config prompt         | ✅ Sprint 3a | `prompts/admin/config-manager-v1.ts` — permission-aware system prompt with reconfirmation flow                                           |
| Sentinel agent                  | ✅ Sprint 3b | `platform/moderation/sentinel.ts` — strike recording, consequence ladder, 5-step trajectory                                              |
| COPPA consent gate              | ✅ Sprint 3b | `platform/auth/coppa-gate.ts` — structural safety (P4), fail-closed, config-driven feature blocking                                      |
| Strike persistence              | ✅ Sprint 3b | `platform/moderation/strikes.ts` — InMemory + Supabase stores, L19 compliant (not fire-and-forget)                                       |
| Sentinel middleware hook        | ✅ Sprint 3b | Guardian block → Sentinel fires async → strike recorded → consequence evaluated                                                          |
| Agent identity rung 2           | ✅ Sprint 3c | `lib/agent-identity.ts` (consumer) — attested delegation: trusted-agent registry, RS256 token verify, rung-1 header retired (ADR-033)    |
| Delegation consent + minting    | ✅ Sprint 3c | OAuth 2.1 / PKCE `/authorize` + `/token`, governed token TTL (per-agent ceiling + global cap), no refresh tokens (ADR-033)               |
| Per-account feature restriction | ✅ Sprint 3c | `platform/auth/account-status-guard.ts` — block a feature for a user, orthogonal to status, fail-closed (ADR-034)                        |
| GenAI-native governance admin   | ✅ Sprint 3c | Registry / capabilities / approval / per-account administered via prompt → plan → confirm → execute; reusable, vocabulary-free (ADR-035) |
| Error tracking (Sentry)         | ✅ Sprint 3  | `platform/observability/error-reporting.ts` — ErrorReporter interface, Sentry + NoOp implementations                                     |
| Distributed tracing             | ✅ Sprint 3  | `platform/observability/tracing.ts` — TraceProvider interface, trace/span lifecycle, header propagation                                  |
| Metrics persistence             | ✅ Sprint 3  | `platform/observability/metrics-sink.ts` — MetricsSink interface, InMemory + Supabase implementations                                    |
| Health monitoring               | ✅ Sprint 3  | `platform/observability/health.ts` — HealthRegistry + probes for Supabase, LLM provider, generic HTTP                                    |
| AI metrics → MetricsSink        | ✅ Sprint 3  | AI instrumentation now delegates to MetricsSink for persistent storage alongside in-memory buffer                                        |
| Logger trace context            | ✅ Sprint 3  | `lib/logger.ts` — traceId/spanId fields, withTrace() scoped logger, documented log entry schema                                          |
| Streaming responses             | ✅ Sprint 5  | `provider.stream()` + `orchestrator.stream()`, TTFT instrumentation, circuit breaker, fallback to complete()                             |

---

## Phase 3 — Language & Voice Foundation ✅

| Capability                       | Status       | Detail                                                                                      |
| -------------------------------- | ------------ | ------------------------------------------------------------------------------------------- |
| Translation provider abstraction | ✅ Sprint 1  | TranslationProvider interface, Google implementation, 10-language config, cache integration |
| Voice provider abstraction       | ✅ Sprint 2  | TTSProvider + STTProvider interfaces, TTS chunker (5,000-byte limit fix), 10 voice configs  |
| Agentic voice pipeline           | ✅ Sprint 3  | VoicePipeline: STT → safety → translate → TTS, P15-P18 agentic context, ADR-019             |
| Song identification              | ✅ Sprint 4a | SongIdentificationProvider (ACRCloud), AudioFormatConverter, canonical format, ADR-020      |
| Cost tracking per call           | ✅ Sprint 4a | estimatedCostUsd on IdentifyResult + ConversionResult (P5)                                  |
| Provider-aware orchestration     | ✅ Sprint 4a | 10 provider slots, all env-var swappable (P7)                                               |
| AI response caching              | ⏳ Deferred  | Moved to Phase 4 — needs RAG/embedding infrastructure                                       |
| Token tracking                   | ⏳ Deferred  | Moved to Phase 6 — aligns with monetization token budgets                                   |
| Enhanced moderation              | ⏳ Deferred  | Moved to Phase 4 — aligns with content safety foundation                                    |
| Multi-language AI                | ⏳ Deferred  | Moved to Phase 4 — needs multi-language safety classification                               |
| AI evaluation framework          | ⏳ Deferred  | Moved to Phase 4 — needs RAG test datasets (ADR-017 §4)                                     |

---

## Phase 4 — Content Safety Foundation ✅

| Capability               | Status      | Detail                                                                                                           |
| ------------------------ | ----------- | ---------------------------------------------------------------------------------------------------------------- |
| RAG foundation           | ✅ Sprint 5 | `platform/rag/` — sliding-window + sentence chunker, retrieval pipeline, budget-aware context injector (ADR-023) |
| Embedding store          | ✅ Sprint 5 | EmbeddingProvider (registry slot) + InMemoryEmbeddingStore (cosine); pgvector migration 017                      |
| User AI context store    | ✅ Sprint 5 | Per-user episodic/semantic/procedural cognitive memory (P16), injected into AI prompts (ADR-017 §5)              |
| AI output explainability | ✅ Sprint 5 | Explainability chain builder for every AI decision (ADR-017 §6)                                                  |

---

## Phase 5 — Application Framework ⏳

| Capability                 | Status     | Detail                                                                                                                |
| -------------------------- | ---------- | --------------------------------------------------------------------------------------------------------------------- |
| Adaptive AI behavior       | ⏳ Planned | LLM-driven adaptive behavior framework — consumers implement app-specific logic (e.g., opponents, tutors, assistants) |
| Dynamic content generation | ⏳ Planned | AI-generated contextual content — consumers define content types and templates                                        |
| Application-specific RAG   | ⏳ Planned | RAG foundation (Phase 4) extended with app-specific knowledge bases and context                                       |
| Agentic workflow framework | ⏳ Planned | `platform/ai/agent.ts` — tool registry, multi-step execution, state, rollback (ADR-017 §7)                            |
| Multimodal AI              | ⏳ Planned | Image/audio input in provider interface, image generation (ADR-017 §8)                                                |

---

## Phase 6 — Monetization Foundation ⏳

| Capability                | Status     | Detail                                                                       |
| ------------------------- | ---------- | ---------------------------------------------------------------------------- |
| Token budget system       | ⏳ Planned | Per-subscription-tier token allowances, enforcement at orchestration layer   |
| Cost attribution per tier | ⏳ Planned | Know how much AI each subscription tier actually consumes                    |
| AI A/B testing            | ⏳ Planned | Split-test prompt versions and model tiers against live traffic (ADR-017 §9) |

---

## Phase 7 — Analytics Foundation ⏳

| Capability             | Status     | Detail                                                                                  |
| ---------------------- | ---------- | --------------------------------------------------------------------------------------- |
| AI quality monitoring  | ⏳ Planned | Hallucination detection, user satisfaction signals, response quality tracking           |
| Analytics intelligence | ⏳ Planned | Natural language querying — "how is my app performing this week?"                       |
| Personalization        | ⏳ Planned | User experience adapted via behavior, skill, preferences                                |
| User feedback loop     | ⏳ Planned | Thumbs up/down, correction tracking, appeal outcomes feeding into quality (ADR-017 §10) |
| Cost dashboards        | ⏳ Planned | Token cost per user, per feature, per app, per subscription tier                        |

---

## Phase 8 — Hardening & Launch ⏳

| Capability               | Status     | Detail                                                                  |
| ------------------------ | ---------- | ----------------------------------------------------------------------- |
| AI hardening             | ⏳ Planned | Fallback chains across providers, graceful model degradation            |
| Chaos engineering for AI | ⏳ Planned | Deliberately break AI in staging — verify fallback and degradation work |

> **Note:** Consumer-specific AI capabilities (e.g., conversational onboarding, in-app AI
> support, anomaly detection) are built in consumer repos using the platform's agentic
> framework (Phase 5), RAG pipeline (Phase 4), and orchestration layer (Phase 2).

---

## Launch Verification Checklist (ADR-017)

At launch, every one of these must be true:

| #   | Statement                                                                    | Verified |
| --- | ---------------------------------------------------------------------------- | -------- |
| 1   | No raw LLM API call exists anywhere in the codebase                          | [ ]      |
| 2   | Every AI call is instrumented with model, tokens, cost, latency              | [ ]      |
| 3   | Every AI input AND output is safety-screened                                 | [ ]      |
| 4   | Every prompt is versioned, tested, and has an eval dataset                   | [ ]      |
| 5   | AI operates in the user's language natively                                  | [ ]      |
| 6   | AI remembers user context across sessions                                    | [ ]      |
| 7   | AI decisions are explainable to admins and users                             | [ ]      |
| 8   | AI supports streaming for conversational surfaces                            | [ ]      |
| 9   | AI supports multimodal input and output                                      | [ ]      |
| 10  | Multi-step AI workflows use the agentic framework                            | [ ]      |
| 11  | Prompt changes are A/B tested against live traffic                           | [ ]      |
| 12  | User feedback flows back into AI quality improvement                         | [ ]      |
| 13  | AI is resilient — fallback providers, circuit breakers, graceful degradation | [ ]      |
| 14  | AI cost is tracked per user, per feature, per app, per subscription tier     | [ ]      |

If any statement is false at launch, GenAI-native is incomplete.

---

## Changelog

| Date       | Author    | Change                                                                                                                                                                                                                                                                                                                                                                                                             |
| ---------- | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 2026-04-06 | Raman Sud | Initial GenAI roadmap — extracted from ADR-015, ADR-017, and ROADMAP.md. Phase 1 complete, Phase 2 Sprint 1+2 complete.                                                                                                                                                                                                                                                                                            |
| 2026-04-06 | Raman Sud | Generalized for platform-foundation: player→user, game→application, Phase 8 app implementation moved to consumer repos. Phase 9→Phase 8 (hardening).                                                                                                                                                                                                                                                               |
| 2026-04-06 | Raman Sud | Sprint 3 complete: Observability fabric added (6 items). Streaming deferred to Sprint 5 (real-time). Phase 2 now 3 of 6 sprints complete.                                                                                                                                                                                                                                                                          |
| 2026-04-16 | Raman Sud | Phase 3 complete. Translation, voice, pipeline, song ID providers delivered. 5 GenAI capabilities deferred to Phase 4/6 (caching, token tracking, enhanced moderation, multi-language AI, eval framework).                                                                                                                                                                                                         |
| 2026-04-27 | Raman Sud | Sprint 3c/3d. Song-ID duration config (P13). Health probe wired (P3). Profile field screening through Guardian (P4). Account-status guard (P4, P11). Auth on all routes. authFetch wrapper. 4 agents active (Guardian, Config Manager, Sentinel + health probe adapter).                                                                                                                                           |
| 2026-04-29 | Raman Sud | Sprint 4a. Social data model (groups, memberships, invites). Agent runtime (registry, tools, trajectory store, budget tracker, execution engine). 12 provider slots. ADR-021, ADR-022. Coverage 86.47%.                                                                                                                                                                                                            |
| 2026-04-30 | Raman Sud | Sprint 4b. 5 social agent workflows (matchmaker, gatekeeper, concierge, analyst, curator) with versioned prompts. AgentClassifier + AgentIntentResolver swap rule-based impls via conductor DI. 7 prompt files, all with sanitizeForPrompt + fail-closed parsing. 16/18 GenAI principles active (P14 deferred to Phase 7, P16 schema-ready with optional previous-result fields).                                  |
| 2026-06-11 | Raman Sud | Phase 4 complete. RAG foundation, pgvector embedding store, cognitive memory (P16), explainability chain delivered (Sprint 5). Guardian/Sentinel moderation agents, human review + appeals (P10), config agent, 6 social agents, and the full agent runtime delivered across Sprints 1-6. Provider conformance kits (ADR-027) close the phase: executable behavioral contract per abstraction, meta-test enforced. |

| 2026-08-04 | Raman Sud | Phase 5 Sprint 2. Agentic workflow framework: tool invocation routed through the governed action pipeline (ADR-029 D2), so a restricted tool is gated by the code that gates a restricted session action. Schemas enforced at both tool edges with retry rather than coercion (D3) — a plausible wrong answer is worse than a loud failure. Trajectories, budgets, proposals and external effects made durable. Gated actions held rather than refused, with approval reconciled against the version the approver saw. Rollback appends compensating actions; history is never rewritten. Failure is three-valued — an external effect that neither confirmed nor denied propagates as `indeterminate` rather than being collapsed into success or failure. P2, P4, P12, P13, P15, P17, P18 strengthened. |

| 2026-08-30 | Raman Sud | Sprint 3c. Agent governance + identity: agent identity rung 2 (ADR-033) — governed trusted-agent registry, RS256 attested delegation (verify + OAuth 2.1/PKCE mint), governed token TTL, rung-1 header retired. Per-account feature restriction (ADR-034), orthogonal to status, fail-closed. GenAI-native governance admin (ADR-035) — registry, capability map, approval policy, and per-account blocks administered through the natural-language admin; a reusable, vocabulary-free platform capability inherited by any consumer with agents. |

_Last updated: September 8, 2026 (Sprint 4b — Phase 5 status row brought current through Sprint 4b: AUX, agent identity + governance, agent registry unification)_
